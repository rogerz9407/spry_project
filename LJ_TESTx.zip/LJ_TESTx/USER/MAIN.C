/*****************************************************
主控模块，控制所有的模块动作
与其他模块采用485总线通信
计划本模块地址为 01
5M超声波模块为  11
30cm模块为      12

与读卡器使用232总线通信
232为串口1   485为串口2

调试信息为串口3输出
*****************************************************/

#include "main.h"

const uint16_t BOARDER_5M = 1200;
const uint16_t BOARDER_30CM = 100;

uint32_t Milisec = 0;    //毫秒计数
uint32_t Second = 0;     //秒计数
uint32_t MAIN_Event = 0; //主程序任务

uint32_t Process_Status = 0; //测量进程状态

uint16_t Dis_5M = 0;   // 5m传感器的距离
uint16_t Dis_30CM = 0; // 30cm传感器距离

uint8_t Inner_Status = 0; //进程内状态
uint8_t Status_5M = 0;    // 5m的状态位

uint8_t Ultra5M_Error = 0; // 5m传感器距离错误

uint8_t RFTEST[30] = {0};

uint8_t Car_Plate[7] = {0};

float Temperature_Now;  //当前读到的温度
float Temperature_Last; //上次的温度
uint8_t Temp_Status;

uint16_t Putter_Current; //推杆电流

uint8_t Putter_Time = 0; //根据5m距离得到的推杆伸出大概时间

char Send_Buf[50];

int main(void) {
  uint8_t i=1;
  RCC_Configuration();  //时钟配置
  GPIO_Configuration(); // gpio配置
  EXTI_Configuration();
  L298_Configuration();
  NVIC_Configuration();
  USART_Configuration(); //串口配置
  delay_init();          // systick时钟配置
  TIM_Configuration();   //定时器配置
  ADC_Configuration();
  DMA_Configuration();
 // delay_ms(1000);
  PROTOCOL_ReadBasicOPt();
  L298_SetOut1BToA();
  delay_ms(500);
  /*while (1) {
    //判断电流
    delay_ms(500);
    HWCT_GetPutterCurrent(&Putter_Current);
    printf("Putter Current: %d\r\n", Putter_Current);
    if (Putter_Current < 100) {
      printf("Putter Current OK\r\n");
      L298_ResetAllOut();
      break;
    }
    if (Milisec > 55000) {
      printf("Wrong with Putter\r\n");
      L298_ResetAllOut();
      break;
    }
  }
   //USART_SendString(USART3, "\r\nSYSTEM OK\r\n", 0);
     //Process_Status = PROCESS_INMESURE;
   while (1) {

     NTC_GetTemperature(&Temperature_Now);
     printf("Temperature_NOW: %.2f\r\n", Temperature_Now);
		 delay_ms(1500);
     Temperature_Last=Temperature_Now;
		 printf("Temperature_LAST: %.2f\r\n", Temperature_Last);
     delay_ms(1500);

     //NTC_GetTemperature(&Temperature_Now);
     //if((Temperature_Now-Temperature_Last<0.1))
    // {
    //   printf("FINISHED\r\n");
    //   i=0;
    // }
   }

 }*/

 //收回推杆
  //RFID_ControlBeeP(20, 0, 1);
  delay_ms(1000);
  IWDG_Init(6, 2000);
  USART_SendString(USART3, "\r\nSYSTEM OK\r\n", 0);
  Milisec = 1;
  MAIN_Event = 0;
	Process_Status = PROCESS_WAITRFID;
	 USART_SendString(USART2, "\r\nSYSTEM OK\r\n", 0);
  while (1) {
    // while (1) {
    //   i = RFID_GetRightCard(RFTEST);
    //   if (i == READOK) {
    //     printf("Read OK: ");
    //     RFID_ControlBeeP(8, 0, 1);
    //     USART_SendString(USART3, RFTEST, 6);
    //     printf("\r\n");
    //   } else if (i == NORESP) {
    //     printf("NO RESPONS\r\n");
    //   } else if (i == NOCARD) {
    //     printf("No Card\r\n");
    //     // RFID_ControlBeeP(2, 2, 3);
    //   } else if (i == CRC_ERROR) {
    //     printf("CRC Error\r\n");
    //   } else if (i == MULTICARD) {
    //     printf("Multi Card\r\n");
    //   } else {
    //     printf("ERROR\r\n");
    //   }
    //   // RFID_ControlBeeP(10, 10, 10);
    //   delay_ms(1000);
    // }
    if (MAIN_Event & MAIN_ULTRACHECK) {
      //发送指令读取550的距离。并判断
      // HWCT_GET_30CMVALUE(&Dis_30CM);
      NTC_GetTemperature(&Temperature_Now);
      printf("Temperature: %.2f\r\n", Temperature_Now);
      if (HWCT_GET_5MVALUE(&Dis_5M) == 1) {
        printf("5M_Distance: %d  ", Dis_5M);
        if (Process_Status == PROCESS_IDLE) {
          if (Dis_5M < BOARDER_5M && Dis_5M != 0) { //空气高度小于了测量边界
            Status_5M++;
            if (Status_5M > 3) {
              printf("Have Vehicle In."); //"\r\n");
              //检测到有车辆
              Status_5M = 0;
              if (Dis_5M > 900) {
                Putter_Time = 60;
              } else {
                Putter_Time = Dis_5M / 8;
              }
              printf("  %d\r\n", Putter_Time);
              Process_Status = PROCESS_WAITRFID;
              // MAIN_Event |= MAIN_READRFID;
            } else {
              printf("\r\n");
            }
          } else {
            Status_5M = 0;
            printf("Position OK\r\n");
          }
        } else if (Process_Status == PROCESS_PUTTERBACK) {
          printf("\r\n");
          //回收推杆过程 不需要关注距离
        } else if (Process_Status == PROCESS_WAITNOTRUCK) {
          if ((Dis_5M > BOARDER_5M + 0) || (Dis_5M == 0)) {
            //距离大于了检测高度加以定的系数
            printf("No Truck\r\n");
            Process_Status = PROCESS_IDLE;
            Inner_Status = 0;
            Status_5M = 0;
            HWCT_GreenLight(0); //灭绿灯
          } else {
            printf("Still Wait Truck Leave\r\n");
          }
          //等待卡车离开
        } else {                                        //在其他状态下
          if ((Dis_5M > BOARDER_5M) || (Dis_5M == 0)) { //距离大于了边界
            printf("Vehicle Position Wrong.\r\n");
            //需增加
            //综合判断温度
            Ultra5M_Error++;
            if ((Ultra5M_Error & 0x0F) > 3) {
              Ultra5M_Error = 0;
              if (Process_Status == PROCESS_WAITRFID) {
                printf("Abort Measue, Putter Back\r\n");
                L298_SetStop();
                //多次发现距离在边界外
                //尝试终止探测收起推杆
                Inner_Status = 0;
                Process_Status = PROCESS_PUTTERBACK;
                MAIN_Event = MAIN_PUTTERBACK;
              }
            }
          } else { //距离仍在界限内
            printf("\r\n");
            //距离正常
            Ultra5M_Error = 0;
          }
        }
      } else { //没有得到正确的回复
        Ultra5M_Error += 0x10;
        if ((Ultra5M_Error & 0xF0) > 0x30) {
          //如果在检测中，是否需要终止检测
          printf("5M WRONG\r\n");
          // USART_Send485Data("#SYSTEM RESTART NOW#\r\n", 0);
          Ultra5M_Error = 0;
        }
      }
      MAIN_Event ^= MAIN_ULTRACHECK;
    }
    if (MAIN_Event & MAIN_READRFID) {
      //循环读取是否有卡存在
      //读到正确的内容后，结束此步
      //计数，超过计数时间没有卡则认为失败
      //直接通过读取函数得到车牌号
      if (Inner_Status == 0) {
        Second = 0;
        Inner_Status = 1;
        for (i = 0; i < 7; i++) { //清零车牌
          Car_Plate[i] = 0;
        }
        printf("Begin Check RFID\r\n");
      } else {
        // printf("Still Checking\r\n");
      }
      // i = RFID_GetRightCard(Car_Plate);
      i = HWCT_ReadCarPlate(Car_Plate); //更改为从串口得到车牌号
      if (i == READOK) {
        printf("Get Car Plate : ");
        RFID_ControlBeeP(8, 0, 1);
        USART_SendString(USART3, Car_Plate, 6);
        printf("\r\n");
				USART_Send485Data("*SLOK*\r\n", 8);
        Process_Status = PROCESS_PUTTEROUT;
        // MAIN_Event |= MAIN_MOVEPUTTER;
        HWCT_RedLight(1); //亮红灯
        Inner_Status = 0;
				Putter_Time = 60;
      }
//      if (Second > 120) { //始终没有读到卡
//        printf("Out of Time\r\n");
//        Process_Status = PROCESS_WAITNOTRUCK;
//        Inner_Status = 0;
//      }
      MAIN_Event ^= MAIN_READRFID;
    }
    if (MAIN_Event & MAIN_MOVEPUTTER) {
      if (Inner_Status == 0) {
        Second = 0; //清零秒计数
        printf("Out the PUTTER\r\n");
        //开始移动推杆
        L298_SetOut1AToB();
        //先启动30cm探头电源
        USART_SendString(USART1, "Open the 30cm Sensor\r\n", 0);
        HWCT_30CM_Power(1);
        delay_ms(500);
        Inner_Status = 1;
      }
      if (Inner_Status == 1) {
        if (HWCT_30CM_SetTem() == 1) {
          printf("Set Tem OK\r\n");
          Inner_Status = 2;
        } else {
          printf("Set Tem Error\r\n");
        }
      }
      //要判断30cm的当前距离，或者读输入的开关量
      //同时判断温度。
      //也要判断驱动的电流，过大过小都会停止。
      //距离过小将停止移动
      HWCT_GET_30CMVALUE(&Dis_30CM);
      NTC_GetTemperature(&Temperature_Now);
      HWCT_GetPutterCurrent(&Putter_Current);
      printf("\r\n30CM_Distance: %d  ", Dis_30CM);
      printf("Temperature: %.2f  ", Temperature_Now);
      printf("Putter_Current: %d\r\n\r\n", Putter_Current);
      if ((Dis_30CM < BOARDER_30CM) && (Dis_30CM != 0)) { //已经移动到距离内
        // L298_ResetAllOut();
        L298_SetStop(); //先停机
        printf("In Range\r\n");
        HWCT_30CM_Power(0);
        Process_Status = PROCESS_INMESURE;
        // MAIN_Event |= MAIN_BEGINMEASURE;
        Inner_Status = 0; //清除进程内状态标志
      } else {
        if (Putter_Current < 300) { //推杆的电流小于了工作值
          printf("Current Too Low\r\n");
          L298_SetStop(); //先停机
          HWCT_30CM_Power(0);
          Process_Status = PROCESS_INMESURE;
          // MAIN_Event |= MAIN_BEGINMEASURE;
          Inner_Status = 0; //清除进程内状态标志
          //选择处理方式
        } else { //推杆电流正常
          if (Temperature_Now > 100.0) {
            printf("Temperature is Bigger than 100\r\n");
            L298_SetStop(); //先停机
            HWCT_30CM_Power(0);
            Process_Status = PROCESS_INMESURE;
            Inner_Status = 0; //清除进程内状态标志
            //是否直接进入测温程序
          }
        }
        if (Second > Putter_Time) { //已经超时 还未到位置
          printf("Out of Time.  In measure.\r\n");
          L298_SetStop();     //先停机
          HWCT_30CM_Power(0); //关闭电源
          Process_Status = PROCESS_INMESURE;
          Inner_Status = 0; //清除进程内状态标志
        }
      }
      MAIN_Event ^= MAIN_MOVEPUTTER;
    }
    if (MAIN_Event & MAIN_BEGINMEASURE) {
      if (Inner_Status == 0) {
        Second = 0;
        Temperature_Last = 0.0;
        Inner_Status = 1;
        Temp_Status = 0;
        printf("Begin to Measure T\r\n");
        L298_ResetAllOut();
      } else {
        printf("Still Measuring\r\n");
      }
      NTC_GetTemperature(&Temperature_Now);

			//Temperature_Now+=10;
      printf("Temperature: %.2f\r\n", Temperature_Now);
      if (Second > 15 && Temperature_Now < 50.0) {
	      // Temperature_Now-=10;
        printf("Temperature Too Low\r\n");
        memset(Send_Buf, 0, 40);
        // Temperature_Now += 45.0;
        // sprintf(Send_Buf, "*LT01%s;30.0;AA", Car_Plate);
        sprintf(Send_Buf, "*LT01%s;%.1f###", Car_Plate, Temperature_Now);
        // sprintf(Send_Buf, "%s%02X\r\n", Send_Buf,
                // PROTOCOL_CalcCheckSum((uint8_t *)Send_Buf, strlen(Send_Buf)));
        printf("\r\n%s\r\n", Send_Buf);
        USART_Send485Data((uint8_t *)Send_Buf, 0);
        Process_Status = PROCESS_PUTTERBACK;
        // MAIN_Event |= MAIN_PUTTERBACK;
        Inner_Status = 0;
      }
      // if (Temperature_Now > 155.0) {
      //   //大于了130度
      //   if ((Temperature_Now - Temperature_Last) < 0.1) {
      //     //温差小于0.3度
      //     //发送数据
      //     //结束测量
      //     Temp_Status++;
      //     if (Temp_Status > 10) {
      //       printf("Finish Measure\r\n");
      //       printf("\r\nCar Plate: %s Temp: %.2f\r\n", Car_Plate,
      //              Temperature_Now);
      //       memset(Send_Buf, 0, 40);
      //       sprintf(Send_Buf, "*LT01%s;%.1f;", Car_Plate, Temperature_Now);
      //       sprintf(
      //           Send_Buf, "%s%02X\r\n", Send_Buf,
      //           PROTOCOL_CalcCheckSum((uint8_t *)Send_Buf,
      //           strlen(Send_Buf)));
      //       printf("\r\n%s\r\n", Send_Buf);
      //       USART_Send485Data((uint8_t *)Send_Buf, 0);
      //       Process_Status = PROCESS_PUTTERBACK;
      //       // MAIN_Event |= MAIN_PUTTERBACK;
      //       Inner_Status = 0;
      //     }
      //   } else {
      //     Temp_Status = 0;
      //   }
      // }
      Temperature_Last = Temperature_Now;
      if ((Second > 100)) { //} && (Temperature_Now < 50.0)) { // 20秒后
				    //if(Temperature_Now > 100)
				//{
			       //	Temperature_Now += 15;
			//	}
        printf("Temperature Out of Time\r\n");
        memset(Send_Buf, 0, 40);
        //Temperature_Now += 15.0;
        printf("\r\nCar Plate: %s Temp: %.2f\r\n", Car_Plate, Temperature_Now);
        sprintf(Send_Buf, "*LT01%s;%.1f###", Car_Plate, Temperature_Now);
        // sprintf(Send_Buf, "%s%02X\r\n", Send_Buf,
                // PROTOCOL_CalcCheckSum((uint8_t *)Send_Buf, strlen(Send_Buf)));
        printf("\r\n%s\r\n", Send_Buf);
        USART_Send485Data((uint8_t *)Send_Buf, 0);
        Process_Status = PROCESS_PUTTERBACK;
        // MAIN_Event |= MAIN_PUTTERBACK;
        Inner_Status = 0;
        // 动作  结束测温?
      }
      // 开始温度测量，
      // 超时结束，达标结束。中间距离改变也会结束？
      // 结束后发送数据？
      // if (Second > 10) {
      //   printf("Finish Measure\r\n");
      //   printf("\r\nCar Plate: %s Temp: %.2f\r\n", Car_Plate,
      //   Temperature_Now);
      //   printf("Car Plate: %s Temp: %.2f\r\n\r\n", Car_Plate,
      //   Temperature_Now);
      //   Process_Status = PROCESS_PUTTERBACK;
      //   // MAIN_Event |= MAIN_PUTTERBACK;
      //   Inner_Status = 0;
      // }
      MAIN_Event ^= MAIN_BEGINMEASURE;
    }
    if (MAIN_Event & MAIN_PUTTERBACK) {
      //收回同时，关闭30cm的电源
      if (Inner_Status == 0) {
        Second = 0;
        Inner_Status = 1;
        printf("Putter Back\r\n");
        L298_SetOut1BToA();
        HWCT_30CM_Power(0);
        MAIN_Event ^= MAIN_PUTTERBACK;
        continue;
        // } else {
        // printf(".");
      }
      //等待推杆的电流为0;
      HWCT_GetPutterCurrent(&Putter_Current);
      printf("Putter_Current: %d\r\n\r\n", Putter_Current);
      if (Putter_Current < 200) {
        printf("Putter OK\r\n");
        L298_ResetAllOut();
        Process_Status = PROCESS_WAITRFID;
        Inner_Status = 0;
        HWCT_RedLight(0);   //灭红灯
      //  HWCT_GreenLight(1); //亮绿灯
        RFID_ControlBeeP(20, 0, 1);
      }
      if (Second > 75) { //超时`
        //错误处理
        RFID_ControlBeeP(5, 0, 1);
        printf("Out of Time.  Putter Error.\r\n");
        Process_Status = PROCESS_WAITRFID;
        HWCT_RedLight(0);   //灭红灯
     //   HWCT_GreenLight(1); //亮绿灯
        Inner_Status = 0;
      }
      //收回推杆，可采取计时方式，或读驱动电流
      //收回成功后，基本结束了一次测量
      MAIN_Event ^= MAIN_PUTTERBACK;
    }
    if (MAIN_Event & MAIN_INTERRUPT) {
      printf("\r\nInterrupt abort measure\r\n\r\n");
      L298_ResetAllOut();
      HWCT_30CM_Power(0);
      Inner_Status = 0;
      Process_Status = PROCESS_PUTTERBACK;
      MAIN_Event ^= MAIN_INTERRUPT;
    }

    if (MAIN_Event & MAIN_CLEARCOUNT) {
      Milisec = 0;
      MAIN_Event ^= MAIN_CLEARCOUNT;
    }
    if (MAIN_Event & MAIN_SYSRESTART) {
      __set_FAULTMASK(1); // 关闭所有中端
      NVIC_SystemReset(); // 复位
    }
  }
}

void TIM4_IRQHandler(void) {
  if (TIM4->SR & TIM_IT_Update) {
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    Milisec++;
    if (Process_Status == PROCESS_WAITRFID) {
      if (Milisec % 200 == 0) {
        MAIN_Event |= MAIN_READRFID;
      }
    }
    //if (Milisec % 3000 == 0) {
    //  MAIN_Event |= MAIN_ULTRACHECK;
    //}
    if (Milisec % 1000 == 0) { // 1秒
      Second++;
      if (Second == 1000) {
        Second = 0;
      }
    }
    if (Milisec % 2000 == 0) {
      switch (Process_Status) {
      case PROCESS_IDLE:
        printf("\r\nProcess IDLE\r\n\r\n");
        break;
      case PROCESS_WAITRFID:
        printf("\r\nProcess WAIT RFID\r\n\r\n");
        break;
      case PROCESS_PUTTEROUT:
        printf("\r\nProcess Putter Out\r\n\r\n");
        MAIN_Event |= MAIN_MOVEPUTTER;
        break;
      case PROCESS_INMESURE:
        printf("\r\nProcess In Measure\r\n\r\n");
        MAIN_Event |= MAIN_BEGINMEASURE;
        break;
      case PROCESS_PUTTERBACK:
        printf("\r\nProcess Putter Back\r\n\r\n");
        MAIN_Event |= MAIN_PUTTERBACK;
        break;
      case PROCESS_WAITNOTRUCK:
        printf("\r\nProcess Wait No Truck\r\n\r\n");
        break;
      default:
        break;
      }
    }
    if (Milisec % 4000 == 0) {
      IWDG->KR = (uint16_t)0xAAAA;
    }
    if (Milisec % 10000 == 0) {
      MAIN_Event |= MAIN_CLEARCOUNT;
    }
    if (Milisec == 60000) {
      Milisec = 0;
      // __set_FAULTMASK(1); // 关闭所有中端
      // NVIC_SystemReset(); // 复位
    }
  }
}

void EXTI4_IRQHandler(void) {
  if (EXTI->PR & EXTI_Line4) {
    delay_ms(10);
    if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0) {
      MAIN_Event |= MAIN_INTERRUPT;
    }
    EXTI->PR = EXTI_Line4;
  }
}
