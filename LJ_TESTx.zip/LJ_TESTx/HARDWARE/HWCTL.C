#include "hwctl.h"

uint8_t HW_RW_Buf[200];

//读取5m超声波的当前空气高度
// 5m模块的ID为11
uint8_t HWCT_GET_5MVALUE(uint16_t *Value) {
  uint8_t i = 0;
  uint16_t len;
  uint16_t Height;
  char *ptr;
  // USART_ClearBuf(&USART2_Data);
  USART_Send485Data("$RA1119\r\n", 9);
  do {
    delay_ms(50);
    i++;
    if (USART_CheckRec(&USART2_Data, "\r\n")) {
      len = USART_CopyData(HW_RW_Buf, &USART2_Data);
      USART_ClearBuf(&USART2_Data);
      if (len > 0) {
        ptr = strstr((char *)HW_RW_Buf, "*RA11");
        if (ptr != NULL) { //*RA11000000AA
          ptr[11] = 0;
          Height = atoi(&ptr[5]);
          if ((Height > 300) && (Height < 7001)) {
            *Value = Height;
            return 1;
          } else if (Height == 0) {
            *Value = 0;
            return 1;
          }
        }
      }
      *Value = 5000;
      return 0;
    }
  } while (i < 10);
  *Value = 5000;
  return 0;
}

//读取30cm超声波的当前空气高度
// 30cm模块的ID为12
uint8_t HWCT_GET_30CMVALUE(uint16_t *Value) {
  uint8_t i = 0;
  uint16_t len;
  uint16_t Height;
  char *ptr;
  USART_Send485Data("$RA121A\r\n", 9);
  do {
    delay_ms(50);
    i++;
    if (USART_CheckRec(&USART2_Data, "\r\n")) {
      len = USART_CopyData(HW_RW_Buf, &USART2_Data);
      USART_ClearBuf(&USART2_Data);
      if (len > 0) {
        ptr = strstr((char *)HW_RW_Buf, "*RA12");
        if (ptr != NULL) { //*RA12000000AA
          ptr[11] = 0;
          Height = atoi(&ptr[7]);
          if ((Height > 50) && (Height <= 300)) {
            *Value = Height;
            return 1;
          } else if (Height == 0) {
            *Value = 300;
            return 1;
          }
        }
      }
      *Value = 300;
      return 0;
    }
  } while (i < 10);
  *Value = 300;
  return 0;
}

//给30CM设置温度值
uint8_t HWCT_30CM_SetTem(void) {
  uint8_t i = 0;
  USART_Send485Data("$ST1200005558\r\n", 15);
  do {
    delay_ms(50);
    i++;
    if (USART_CheckRec(&USART2_Data, "55")) {
      USART_ClearBuf(&USART2_Data);
      return 1;
    }
  } while (i < 10);
  return 0;
}

//打开或关闭30cm电源的端口
void HWCT_30CM_Power(uint8_t Mode) {
  if (Mode) {
    GPIO_SetBits(GPIOB, GPIO_Pin_15);
    //打开对应端口
  } else {
    GPIO_ResetBits(GPIOB, GPIO_Pin_15);
    //关闭端口
  }
}

//从串口获得车牌号
uint8_t HWCT_ReadCarPlate(uint8_t *Plate) {
  char *ptr;
  uint8_t i;
  uint16_t len;
  if (USART_CheckRec(&USART2_Data, "&&&")) {
    len = USART_CopyData(HW_RW_Buf, &USART2_Data);
    USART_ClearBuf(&USART2_Data);
    if (len > 0) {
      ptr = strstr((char *)HW_RW_Buf, "$SL");
      if (ptr != NULL) {
        ptr += 3;
        for (i = 0; i < 6; i++) {
          Plate[i] = ptr[i];
        }
        return 99; // READOK
      }
    }
  }
  return 0;
}

//读取当前的推杆驱动电流
//返回参数为电流值，单位mA
void HWCT_GetPutterCurrent(uint16_t *Current) {
  uint16_t Temp;
  Temp = DMA_GetADCValue(2);
  // Temp = Temp / 2048 * 3300;
  *Current = (uint16_t)(Temp * 1.6113281);
}

//红灯
void HWCT_RedLight(uint8_t Mode) {
  if (Mode) {
    GPIO_ResetBits(GPIOC, GPIO_Pin_5);
  } else {
    GPIO_SetBits(GPIOC, GPIO_Pin_5);
  }
}
//绿灯
void HWCT_GreenLight(uint8_t Mode) {
  if (Mode) {
    GPIO_ResetBits(GPIOB, GPIO_Pin_13);
  } else {
    GPIO_SetBits(GPIOB, GPIO_Pin_13);
  }
}
