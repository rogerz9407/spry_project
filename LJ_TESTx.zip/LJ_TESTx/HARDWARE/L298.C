#include "l298.h"

void L298_Configuration(void) {
  GPIO_InitTypeDef GPIO_InitStructure;

  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

  //推杆1 的控制口配置
  // PA 5 6 7
  GPIO_InitStructure.GPIO_Pin =
      MOTOR1_A_GPIO_PIN | MOTOR1_B_GPIO_PIN | MOTOR1_EN_GPIO_PIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_ResetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
}

//复位所有输出,将几个引脚均置低
uint8_t L298_ResetAllOut(void) {
  GPIO_ResetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  GPIO_ResetBits(MOTOR1_A_GPIO_PORT, MOTOR1_A_GPIO_PIN);
  GPIO_ResetBits(MOTOR1_B_GPIO_PORT, MOTOR1_B_GPIO_PIN);
  //此处应检测引脚电流，为0时返回OK
  //超时仍有电流则返回错误
  return 1;
}

//停机，将所有输出置高
uint8_t L298_SetStop(void) {
  GPIO_SetBits(MOTOR1_A_GPIO_PORT, MOTOR1_A_GPIO_PIN);
  GPIO_SetBits(MOTOR1_B_GPIO_PORT, MOTOR1_B_GPIO_PIN);
  GPIO_SetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  return 1;
}

//将1口置为A 到 B输出模式
uint8_t L298_SetOut1AToB(void) {
  GPIO_ResetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  GPIO_SetBits(MOTOR1_A_GPIO_PORT, MOTOR1_A_GPIO_PIN);
  GPIO_ResetBits(MOTOR1_B_GPIO_PORT, MOTOR1_B_GPIO_PIN);
  GPIO_SetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  //此处可尝试检测电流，或交由外部检测
  return 1;
}

//将1口置为B 到 A输出模式
uint8_t L298_SetOut1BToA(void) {
  GPIO_ResetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  GPIO_SetBits(MOTOR1_B_GPIO_PORT, MOTOR1_B_GPIO_PIN);
  GPIO_ResetBits(MOTOR1_A_GPIO_PORT, MOTOR1_A_GPIO_PIN);
  GPIO_SetBits(MOTOR1_EN_GPIO_PORT, MOTOR1_EN_GPIO_PIN);
  //此处可尝试检测电流，或交由外部检测
  return 1;
}
