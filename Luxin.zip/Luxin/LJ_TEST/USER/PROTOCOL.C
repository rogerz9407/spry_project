//协议文件
//包含了参数处理，存储读取等功能

#include "protocol.h"

PROTOCOL_TypeDef PROTOCOL_Structure;

//从FLASH读一整页时，若使用局部变量，会导致栈溢出！
//使用全局变量可解决！
uint8_t FLASH_RW_Buf[200] = {0};

void PROTOCOL_StructInit(void) {
  PROTOCOL_Structure.Device_ID[0] = '0';    //设备ID
  PROTOCOL_Structure.Device_ID[1] = '1';    //设备ID
  PROTOCOL_Structure.Device_ID[2] = 0;      //设备ID
}

//输出所有的设置信息
void PROTOCOL_SendAllConf(uint8_t OPT) {
  sprintf((char *)FLASH_RW_Buf,"ID: %s\r\n",PROTOCOL_Structure.Device_ID);
  if (OPT == 0) {
    USART_SendString(USART1, FLASH_RW_Buf, 0);
    // USART_Send485Data(FLASH_RW_Buf, 0);
  }
}

//将基本配置信息写入FLASH中
uint8_t PROTOCOL_WriteBasicOPt(void) {
  //  B ID 高度 X Y 类型 时间 安装高度
  memset(FLASH_RW_Buf, 0, 200);
  sprintf((char *)FLASH_RW_Buf, "BASIC:%s:",
          PROTOCOL_Structure.Device_ID);
  // USART_Send485Data("\r\n\r\n", 4);
  // USART_Send485Data("Write: ", 7);
  // USART_Send485Data(FLASH_RW_Buf, 0);
  // USART_Send485Data("\r\n\r\n", 4);
  FLASH_WriteString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf,
                    strlen((char *)FLASH_RW_Buf));
  return 1;
}

//从FLASH中读出基本配置的内容
uint8_t PROTOCOL_ReadBasicOPt(void) {
  PROTOCOL_StructInit(); //对结构体初始化
  FLASH_ReadString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf, 200);
  // printf("\r\n%s\r\n\r\n", FLASH_RW_Buf);
  // USART_Send485Data("Read: ", 6);
  // USART_Send485Data(FLASH_RW_Buf, 400);
  // USART_Send485Data("\r\n\r\n", 4);
  if (FLASH_RW_Buf[0] == 'B' &&
      (strstr((char *)FLASH_RW_Buf, "BASIC:") != NULL)) {
    PROTOCOL_Structure.Device_ID[0] = FLASH_RW_Buf[6];
    PROTOCOL_Structure.Device_ID[1] = FLASH_RW_Buf[7];
    PROTOCOL_Structure.Device_ID[2] = 0;
    PROTOCOL_SendAllConf(0);
    return 1;
  } else {                    //读出失败
    PROTOCOL_StructInit();    //对结构体初始化
    PROTOCOL_WriteBasicOPt(); //写入FLASH 中
    return 0;
  }
}

//读出设备当前ID
//传出数组
void PROTOCOL_ReadDeviceID(uint8_t *DvcID) {
  DvcID[0] = PROTOCOL_Structure.Device_ID[0];
  DvcID[1] = PROTOCOL_Structure.Device_ID[1];
}
//设置设备ID
//传入数组，不检查
void PROTOCOL_WriteDeviceID(uint8_t *DvcID) {
  PROTOCOL_Structure.Device_ID[0] = DvcID[0];
  PROTOCOL_Structure.Device_ID[1] = DvcID[1];
  PROTOCOL_WriteBasicOPt();
}

//计算传入数据的校验和
//直接返回计算的8位数值 不处理！
uint8_t PROTOCOL_CalcCheckSum(uint8_t *Data_In, uint16_t Data_Len) {
  uint16_t i = 0;
  uint8_t Sum_Data = 0;
  if (Data_Len < 5) {
    return 0; //太短 不计算
  }
  for (i = 0; i < Data_Len; i++) {
    Sum_Data = (uint8_t)(Sum_Data + Data_In[i]);
  }
  return Sum_Data;
}

//协议的校验和检查
//只能输入$************XX格式 XX为校验和
uint8_t PROTOCOL_CheckSumCheck(uint8_t *Data_Check) {
  uint16_t Data_Len = 0;
  uint8_t Sum_Data[2] = {0};
  Data_Len = strlen((char *)Data_Check);
  if (Data_Len < 7 || Data_Len > 200) { //短或长了
    return 0;
  }
  Sum_Data[0] = PROTOCOL_CalcCheckSum(Data_Check, Data_Len - 2);
  sprintf((char *)Sum_Data, "%02X", Sum_Data[0]); //转到数组里
  if ((Sum_Data[0] == Data_Check[Data_Len - 2]) &&
      (Sum_Data[1] == Data_Check[Data_Len - 1])) {
    return 1;
  }
  USART_SendString(USART1, "WRONG CHECKSUM   ", 0);
  USART_SendString(USART1, Sum_Data, 2);
  USART_SendString(USART1, "\r\n", 2);
  // USART_Send485Data("WRONG CHECKSUM   ", 0);
  // USART_Send485Data(Sum_Data, 2);
  // USART_Send485Data("\r\n", 2);
  return 0;
}

//检查输入参数的ID
//输入的指针指向$
uint8_t PROTOCOL_IDCheck(uint8_t *ID_Check) {
  ID_Check += 3;
  if (ID_Check[0] == '0' && ID_Check[1] == '0') {
    return 1;
  }
  if (ID_Check[0] == PROTOCOL_Structure.Device_ID[0] &&
      ID_Check[1] == PROTOCOL_Structure.Device_ID[1]) {
    // USART_Send485Data(PROTOCOL_Structure.Device_ID, 2);
    // USART_Send485Data(" ", 1);
    return 1;
  } else {
    // USART_SendString(USART1, "WRONG ID\r\n", 10);
    // USART_Send485Data("WRONG ID\r\n", 10);
    return 0;
  }
}

//特殊指令处理
void PROTOCOL_SPecComDeal(uint8_t *Comm_Data) {
  if (strstr((char *)Comm_Data, "#SYSTEM RESTART NOW#") != NULL) {
    __set_FAULTMASK(1); // 关闭所有中端
    NVIC_SystemReset(); // 复位
  }
  if (strstr((char *)Comm_Data, "#SYSTEM RESTORE NOW#") != NULL) {
    PROTOCOL_StructInit();
    PROTOCOL_WriteBasicOPt();
  }
}

//处理R开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是R所在的地址
uint8_t PROTOCOL_InforProcessRead(uint8_t *Read_Data, uint8_t Source) {

  Read_Data++; //加到下一位
  switch (*Read_Data) {
  case 'C':                  //读取配置
    if (Source == SRCUART) { //串口
      PROTOCOL_SendAllConf(0);
      return 1;
    } else { //其他
      Read_Data--;
      PROTOCOL_SendAllConf(1);
      memcpy(Read_Data, FLASH_RW_Buf, strlen((char *)FLASH_RW_Buf));
      return 1;
    }
  default:
    break;
  }
  return 0;
}

//处理S开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是S所在的地址
//若传入的来源为非串口，则会改写从S开始的内容为传出的内容。
uint8_t PROTOCOL_InforProcessSet(uint8_t *Set_Data, uint8_t Source) {
  Set_Data++;            //到下一位
  switch (*Set_Data) {
  case 'I': //设置ID
    Set_Data += 7;
    PROTOCOL_WriteDeviceID(Set_Data);
    sprintf((char *)FLASH_RW_Buf, "ID: %s\r\n", PROTOCOL_Structure.Device_ID);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      // USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 8;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  default:
    return 0;
  }
  return 1;
}

//传入的协议信息处理
//参数Para为是否判断ID 校验和等。
//参数Source为判断来源，有些指令来源错误不判断
//先判断$ 后判断是否校验和ID 都正常才进流程
//若处理正常，会返回$所在的地址，否则返回NULL
uint8_t *PROTOCOL_InforProcess(uint8_t *Protocol_Data, uint8_t Para,
                               uint8_t Source) {
  uint8_t *ptr1;

  ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '$'); //查找起始符
  if (ptr1 == NULL) {                                   //没找到
    ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '#');
    if (ptr1 != NULL) {
      PROTOCOL_SPecComDeal(Protocol_Data);
    }
    return NULL; // NOSTRCR; //返回错误
  }
  if ((Para & NOCKSCHK) == 0) {              //需要检查校验和
    if (PROTOCOL_CheckSumCheck(ptr1) == 0) { //检查校验和
      return NULL;                           // CHKWRNG;
    }
  }
  if ((Para & NOIDCHK) == 0) {         //需要检查ID
    if (PROTOCOL_IDCheck(ptr1) == 0) { //检查ID
      return NULL;                     // IDWRONG;
    }
  }
  ptr1++;
  switch (*ptr1) {
  case 'S':
    if (strstr((char *)Protocol_Data, "STOP")) {
      L298_ResetAllOut();
      return NULL;
    }
  case 'A':
    if (strstr((char *)Protocol_Data, "ATOB")) {
      L298_SetOut1AToB();
      return NULL;
    }
  case 'B':
    if (strstr((char *)Protocol_Data, "BTOA")) {
      L298_SetOut1BToA();
      return NULL;
    }
  default:
    return NULL;
  }
}
