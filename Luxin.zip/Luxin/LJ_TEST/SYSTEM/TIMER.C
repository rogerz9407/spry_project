#include "timer.h"

void TIM_Configuration(void) {
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  // TIM_ICInitTypeDef	 TIM_ICInitStructure;
  // TIM_OCInitTypeDef TIM_OCInitStructure;

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 |
                             RCC_APB1Periph_TIM4,
                         ENABLE); // 时钟使能TIM2

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE); // 时钟使能TIM2

  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure); //初始化结构体
  // // TIM2作为超声波的驱动发生器
  // TIM_DeInit(TIM2);
  // TIM_TimeBaseStructure.TIM_Period = 34;   // 72/34=2.1M
  // TIM_TimeBaseStructure.TIM_Prescaler = 0; // 72/1=72m
  //
  // TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  // TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // TIM脉冲宽度调制模式1
  // TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  // //比较输出使能
  // TIM_OCInitStructure.TIM_Pulse = 12; //设置待装入捕获比较寄存器的脉冲值
  // TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性 极性高
  // TIM_OC1Init(TIM2, &TIM_OCInitStructure);
  // TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable); // CH1预装载使能
  // TIM_ARRPreloadConfig(TIM2, ENABLE); //使能TIMx在ARR上的预装载寄存器

  // TIM3作为超声波的回波时间计数器
  // TIM_DeInit(TIM3);
  // TIM_InternalClockConfig(TIM3);
  // TIM_TimeBaseStructure.TIM_Period = 3000;  //溢出时间 3000 us
  // TIM_TimeBaseStructure.TIM_Prescaler = 71; // 1m
  // TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  // TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
  // TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
  // TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
  // TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  // TIM_ICInitStructure.TIM_ICFilter = 0x00;
  // TIM_ICInit(TIM3,&TIM_ICInitStructure);
  // TIM3->SR = (uint16_t)~(TIM_IT_Update | TIM_IT_CC2); //清除中断标志
  // TIM_ITConfig(TIM3, TIM_IT_Update | TIM_IT_CC2, ENABLE);

  // TIM4作为基准定时器产生1ms中断！可拿来当时钟以及主程序任务切换
  TIM_DeInit(TIM4);
  TIM_TimeBaseStructure.TIM_Period = 999;   // 60ms中断
  TIM_TimeBaseStructure.TIM_Prescaler = 71; // 1us
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
  TIM_Cmd(TIM4, ENABLE);
}
