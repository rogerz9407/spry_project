
#include "rfid.h"

#define PRESET_VALUE 0xFFFF
#define POLYNOMIAL 0x8408

uint8_t RFID_RW_Buf[200];

uint8_t CARD_EPC[3][10];

// CRC16计算 输入字符和长度
//输出16进制的值
uint16_t RFID_Crc16Cal(uint8_t const *pucY, uint8_t ucX) {
  uint8_t ucI, ucJ;
  uint16_t uiCrcValue = PRESET_VALUE;

  for (ucI = 0; ucI < ucX; ucI++) {
    uiCrcValue = uiCrcValue ^ *(pucY + ucI);
    for (ucJ = 0; ucJ < 8; ucJ++) {
      if (uiCrcValue & 0x0001) {
        uiCrcValue = (uiCrcValue >> 1) ^ POLYNOMIAL;
      } else {
        uiCrcValue = (uiCrcValue >> 1);
      }
    }
  }
  return uiCrcValue;
}

//检查CRC16的校验是否正确
uint8_t RFID_CrcCheck(uint8_t const *Data_Check, uint8_t Len) {
  uint16_t CRCValue;
  CRCValue = RFID_Crc16Cal(Data_Check, Len - 2);
  if (((uint8_t)(CRCValue & 0x00FF) == Data_Check[Len - 2]) &&
      ((CRCValue >> 8) == Data_Check[Len - 1])) {
    return 1;
  }
  return 0;
}

//读取范围内是否有卡
//若有卡的话，将长度与卡号写入参数
uint8_t RFID_ReadCard(uint8_t *EPCNUM, uint8_t *EPCLEN) {
  uint8_t i = 0;
  uint8_t Buf[5] = {0x04, 0x00, 0x01, 0xDB, 0x4B};
  uint8_t Len;
  USART_ClearBuf(&USART1_Data);
  USART_SendString(USART1, Buf, 5);
  do {
    delay_ms(50);
    i++;
    if (USART1_Data.DATA_RX[0] == (USART1_Data.RX_STA - 1)) {
      //得到的长度与指令中的相同
      if (USART1_Data.DATA_RX[2] == 0x01) {
        memset(RFID_RW_Buf, 0, 200);
        Len = USART_CopyData(RFID_RW_Buf, &USART1_Data);
        if (RFID_CrcCheck(RFID_RW_Buf, Len) == 0) {
          return CRC_ERROR; // CRC错误
        }
        switch (RFID_RW_Buf[3]) {
        case 0x01:
          if (RFID_RW_Buf[4] > 0x01) {
            return MULTICARD;
          }
          //复制卡号
          *EPCLEN = RFID_RW_Buf[5];
          for (i = 0; i < *EPCLEN; i++) {
            EPCNUM[i] = RFID_RW_Buf[6 + i];
          }
          return READOK;
        case 0xFB: //没有卡
          return NOCARD;
        default: //错误
          return ERR_ERROR;
        }
      }
    }
  } while (i < 12);
  return NORESP;
}

//控制蜂鸣器函数
//输入参数为：
// ActiveT 鸣叫时间   SilenT 静默时间  单位为 50ms
// Times 重复次数
uint8_t RFID_ControlBeeP(uint8_t ActiveT, uint8_t SilentT, uint8_t Times) {
  uint8_t i = 0;
  uint16_t CRCValue;
  //              长度   地址  命令 Active Silent Times CRCL CRCM
  uint8_t Buf[8] = {0x07, 0x00, 0x33, 0x00, 0x00, 0x00, 0xFF, 0xFF};
  Buf[3] = ActiveT;
  Buf[4] = SilentT;
  Buf[5] = Times;                   //赋值
  CRCValue = RFID_Crc16Cal(Buf, 6); //计算CRC
  Buf[6] = (uint8_t)(CRCValue & 0x00FF);
  Buf[7] = (uint8_t)(CRCValue >> 8);
  USART_ClearBuf(&USART1_Data);
  USART_SendString(USART1, Buf, 8);
  do {
    delay_ms(50);
    i++;
    if (USART1_Data.DATA_RX[0] == (USART1_Data.RX_STA - 1)) {
      switch (USART1_Data.DATA_RX[3]) {
      case 0x00: //成功
        return RESPONSEOK;
      default: //其他情况返回错误
        return ERR_ERROR;
      }
    }
  } while (i < 10);
  return NORESP;
}

//读取当前是否有卡
//若有卡返回正确 并传出车牌号
//正确条件是EPC号必须为6位
uint8_t RFID_GetRightCard(uint8_t *Plate) {
  uint8_t i = 0;
  uint8_t j;
  uint8_t Len, Error_Code;
  while (1) {
    Error_Code = RFID_ReadCard(&CARD_EPC[i][0], &Len);
    if (Error_Code == READOK) { //读到了单张卡号
      if (Len == 6) {           //卡号长度正常
        if (i > 0) {            //第一次不处理
          for (j = 0; j < 6; j++) {
            if (CARD_EPC[i][j] != CARD_EPC[i - 1][j]) {
              printf("Not Correct Card\r\n");
              return ERR_ERROR;
            }
          }
          if (i > 1) { //读到3次了
            printf("Right Card\r\n");
            for (j = 0; j < 6; j++) {
              Plate[j] = CARD_EPC[2][j];
            }
            return READOK;
          }
        }
        i++;
      } else { //长度错误
        printf("Length Wrong\r\n");
        RFID_ControlBeeP(2, 2, 3);
        return ERR_ERROR;
      }
    } else if (Error_Code == MULTICARD) { //读到多张卡
      printf("Multi Card\r\n");
      RFID_ControlBeeP(2, 2, 5);
      return Error_Code;
    } else {
      return Error_Code;
    }
    delay_ms(50);
  }
}
