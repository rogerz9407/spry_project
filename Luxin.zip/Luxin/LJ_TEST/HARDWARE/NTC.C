/*****************************************************************************
Copyright: 2011-2016, Dingtek Company Co., Ltd.
File name: ntc.c
Description:NTC热敏电阻测量函数。
需要热敏电阻B值，25度时电阻值。
测量过程：
1.得到电压值，若有比较电压，同时得到准确电源电压值
2.将电压值转为电阻值
3.将电阻值套入公式，转为温度值。
注意：需DMA函数配合使用

Author: Zitao Wang
Version: 1.0
Date: 2016-05-18
History:
*******************************/

#include "ntc.h"

const float DIV_RES_VALUE = 1.0;
const float NTC_RESON25 = 100.0;
const uint16_t NTC_B_VALUE = 3950;

// 温度与电阻值对应表 从100度开始
const float NTC_Table[120] = {
    /*100*/ 6.7100, 6.5265, 6.3490, 6.1772, 6.0109, 5.8500,
    /*106*/ 5.6832, 5.5221, 5.3663, 5.2156, 5.0700, 4.9291,
    /*112*/ 4.7928, 4.6610, 4.5334, 4.4100, 4.2906, 4.1751,
    /*118*/ 4.0632, 3.9549, 3.8500, 3.7410, 3.6357, 3.5338,
    /*124*/ 3.4353, 3.3400, 3.2550, 3.1726, 3.0927, 3.0152,
    /*130*/ 2.9400, 2.8634, 2.7893, 2.7173, 2.6476, 2.5800,
    /*136*/ 2.5144, 2.4507, 2.3890, 2.3291, 2.2710, 2.2135,
    /*142*/ 2.1577, 2.1035, 2.0510, 2.0000, 1.9513, 1.9040,
    /*148*/ 1.8580, 1.8134, 1.7700, 1.7319, 1.6947, 1.6586,
    /*154*/ 1.6233, 1.5890, 1.5520, 1.5160, 1.4811, 1.4471,
    /*160*/ 1.4140, 1.3812, 1.3494, 1.3184, 1.2883, 1.2590,
    /*166*/ 1.2301, 1.2019, 1.1745, 1.1479, 1.1220, 1.0956,
    /*172*/ 1.0699, 1.0449, 1.0206, 0.9970, 0.9757, 0.9550,
    /*178*/ 0.9348, 0.9151, 0.8960, 0.8750, 0.8547, 0.8349,
    /*184*/ 0.8157, 0.7970, 0.7806, 0.7646, 0.7490, 0.7338,
    /*190*/ 0.7190, 0.7029, 0.6873, 0.6721, 0.6574, 0.6430,
    /*196*/ 0.6302, 0.6177, 0.6055, 0.5936, 0.5820, 0.5717,
    /*202*/ 0.5617, 0.5519, 0.5423, 0.5330, 0.5225, 0.5122,
    /*208*/ 0.5022, 0.4925, 0.4830, 0.4733, 0.4639, 0.4547,
    /*214*/ 0.4457, 0.4370, 0.4284, 0.4200, 0.4118, 0.4038};

float Power_Voltage_3V3 = 3.31;
/*****************************************************
计算输入参数的log值
lndata  计算参数
N 计算深度
*****************************************************/
double mylog(double lndata, uint8_t N) {
  int k, nk;
  double x, xx, y;
  x = (lndata - 1) / (lndata + 1);
  xx = x * x;
  nk = 2 * N + 1;
  y = 1.0 / nk;
  for (k = N; k > 0; k--) {
    nk = nk - 2;
    y = 1.0 / nk + xx * y;
  }
  return 2.0 * x * y;
}

uint8_t NTC_GetVoltage(float *BackVoltage) {
  *BackVoltage = DMA_GetADCValue(1) / 4095.0 * Power_Voltage_3V3;
  return 1;
}
/*****************************************************
将AD电压转为对应的电阻值
Pow_Voltage - 电阻的电源电压值 5V 或3.3V
NTC_Voltage - 热敏电阻的AD电压值
Div_Resist - 分压电阻阻值，单位K
BackResist - 返回值，为对应电阻值，单位K
******************************************************/
uint8_t NTC_VoltageToRes(float Pow_Voltage, float NTC_Voltage, float Div_Resist,
                         float *BackResist) {
  float Resist;
  Resist = NTC_Voltage * Div_Resist;
  Resist /= (Pow_Voltage - NTC_Voltage);
  *BackResist = Resist;

  return 1;
}

/******************************************************
返回对应NTC的温度值;
Resist_On25 - NTC在25度时的阻值，单位K
B - NTC的B值
Resist_Now - 当前得到传感器阻值，单位K

******************************************************/
uint8_t NTC_ResToTemperature(float Resist_On25, uint16_t B, float Resist_Now,
                             float *Tem_Now) {
  float Temp;
  Temp = mylog(Resist_Now / Resist_On25, 10);
  Temp = Temp + B / 298.15;
  Temp = B / Temp - 273.15;
  *Tem_Now = Temp;
  return 1;
}

uint8_t NTC_GetTemperature(float *BackTemperature) {

  float NTC_Voltage;
  float NTC_Resistance;
  float Diff;
  uint8_t i;
  NTC_GetVoltage(&NTC_Voltage); //得到电压值
  printf("\r\nvoltage: %.4f\r\n", NTC_Voltage);
  NTC_VoltageToRes(Power_Voltage_3V3, NTC_Voltage, DIV_RES_VALUE,
                   &NTC_Resistance); //得到电阻值
  printf("Res: %.4f\r\n", NTC_Resistance);
  NTC_ResToTemperature(NTC_RESON25, NTC_B_VALUE, NTC_Resistance,
                       BackTemperature); //得到温度值
  printf("LOG: %.2f\r\n", *BackTemperature);
  if (NTC_Resistance < 6.7) { //电阻小于6.7k 温度大于100度
    // 查表法
    for (i = 1; i < 120; i++) {            //从100度开始查
      if (NTC_Table[i] < NTC_Resistance) { // 实际电阻大于了当前表格温度
        Diff = NTC_Resistance - NTC_Table[i];
        Diff /= (NTC_Table[i - 1] - NTC_Table[i]);
        *BackTemperature = (float)(i + 100) - Diff;
        printf("TAB: %.2f\r\n", *BackTemperature);
        printf("\r\n");
        return 1;
      }
    }
    // *BackTemperature = 222.0;
    printf("\r\n");
    return 1;
  } // else {
  //   NTC_ResToTemperature(NTC_RESON25, NTC_B_VALUE, NTC_Resistance,
  //                        BackTemperature); //得到温度值
  // }
  return 1;
}
