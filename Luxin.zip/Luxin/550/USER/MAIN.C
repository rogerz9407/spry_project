
#include "main.h"

uint32_t Milisec = 0;
uint32_t MAIN_Event = 0;
uint16_t Ultra_UPtimeCount = 0; //自动上传的时间设置 单位是秒
uint16_t Ultra_UPtimeX = 0;     //自动上传的时间存储

// uint8_t UP_Buf[20] = "$RL0022\0";

int main(void) {

  // uint16_t LiQ_Percent = 0;

  RCC_Configuration();  //时钟配置
  GPIO_Configuration(); // gpio配置
  NVIC_Configuration();
  EXTI_Configuration();
  USART_Configuration(); //串口配置
  delay_init();          // systick时钟配置
  TIM_Configuration();   //定时器配置
  delay_ms(1000);
  PROTOCOL_ReadBasicOPt();
  Ultra_UPtimeX = 15;
  delay_ms(1000);
  USART_SendString(USART1,"\r\nSYSTEM OK\r\n",13);
  Milisec = 1;
  MAIN_Event = 0;
  while (1) {
    if (MAIN_Event & MAIN_STARTULTRA) {
      ULTRA_StartDetect();
      MAIN_Event ^= MAIN_STARTULTRA;
    }
    if (MAIN_Event & MAIN_REFRESHDATA) {
      PROTOCOL_RefreshData();
      MAIN_Event ^= MAIN_REFRESHDATA;
    }
    if (MAIN_Event & MAIN_SYSRESTART) {
      __set_FAULTMASK(1); // 关闭所有中端
      NVIC_SystemReset(); // 复位
    }
  }
}

void TIM2_IRQHandler(void) {
  if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    Milisec++;
    if (Milisec % 333 == 0) {
      MAIN_Event |= MAIN_STARTULTRA;
    }
    if (Milisec % 1000 == 0) { // 1秒
      Ultra_UPtimeCount++;
      if (Ultra_UPtimeCount == Ultra_UPtimeX) { //匹配上传时间
        Ultra_UPtimeCount = 0;
        MAIN_Event |= MAIN_REFRESHDATA;
      }
    }
    if (Milisec == 20000) {
      Milisec = 0;
    }
    if (Milisec == 65530) {
      __set_FAULTMASK(1); // 关闭所有中端
      NVIC_SystemReset(); // 复位
      // Milisec = 0;
    }
  }
}
