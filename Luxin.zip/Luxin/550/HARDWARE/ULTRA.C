//超声波控制等函数
#include "ultra.h"

ULTRA_TypeDef ULTRA_Structure;

uint8_t ULTRA_Send_Count = 0;

void ULTRA_StructInit(void) {
  memset(ULTRA_Structure.Echo_Time, 0, 40); //回波时间 单位us
  ULTRA_Structure.Echo_Count = 0;           //回波数量计算
  ULTRA_Structure.IRQ_Time = 0;             //进入中断的次数
  ULTRA_Structure.IRQ_Count = 0;            // TIM4计数的次数
  ULTRA_Structure.Average_Time = 0;         //平均时间
}

//超声波开启定时器启动探头进行测量
void ULTRA_StartDetect(void) {
  EXTI->IMR &= ~EXTI_Line11; //关闭11线的外部中断
  TIM4->CNT = 0;
  TIM4->CR1 |= TIM_CR1_CEN; //打开中断
  TIM3->CR1 |= TIM_CR1_CEN; //打开中断
}

//返回当前测得的空气高度
//返回16位数据，单位为mm
void ULTRA_ReadAirHeight(uint16_t *Air_Height) {

  uint16_t Air_Temp;
  Air_Temp = (uint16_t)(ULTRA_Structure.Average_Time * 17.0 / 100.0);
  if (Air_Temp > ULTRARANGE) { //计算得到空气高度大于了最大高度
    *Air_Height = ULTRARANGE;
  } else {
    *Air_Height = Air_Temp;
  }
}

//处理回波信息
void ULTRA_EchoHandler(void) {
  ULTRA_Structure.IRQ_Count = TIM4->CNT;
  ULTRA_Structure.Echo_Time[ULTRA_Structure.Echo_Count] =
      ULTRA_Structure.IRQ_Time * 60000 + ULTRA_Structure.IRQ_Count; //整合时间
  ULTRA_Structure.IRQ_Count = 0;
  ULTRA_Structure.IRQ_Time = 0; //清零
  ULTRA_Structure.Echo_Count++;
  if (ULTRA_Structure.Echo_Count == 10) { //收到10次后计算一次平均
    Bubble_Sort(ULTRA_Structure.Echo_Time, 10); //取了中间6个数
    ULTRA_Structure.Average_Time =
        Get_Average(&ULTRA_Structure.Echo_Time[2], 6);
    ULTRA_Structure.Echo_Count = 0; //清零计数
  }
}

// TIM3中断驱动超声波
void TIM3_IRQHandler(void) {
  if (TIM3->SR & TIM_IT_Update) {
    TIM3->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
    ULTRA_Send_Count++;
    if (ULTRA_Send_Count <= ULTRACOUNT) {
      if (ULTRA_Send_Count % 2 == 0) {
        GPIOB->BSRR = GPIO_Pin_8;
      } else {
        GPIOB->BRR = GPIO_Pin_8;
      }
    } else {
      TIM3->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN)); //关闭计数
      EXTI->IMR |= EXTI_Line11; //打开11线的外部中断
      ULTRA_Send_Count = 0;
    }
  }
}

// TIM4 中断回波时间计算
void TIM4_IRQHandler(void) {
  if (TIM4->SR & TIM_IT_Update) {
    TIM4->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
    if (ULTRA_Structure.IRQ_Time == 1) { //第二次进中断 超范围了
      TIM4->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN)); //关闭计数
      ULTRA_Structure.IRQ_Time = 0;                      //清零
    } else {                                             //正常
      ULTRA_Structure.IRQ_Time++;
    }
  }
}

void EXTI15_10_IRQHandler(void) {
  if (EXTI->PR & EXTI_Line11) {
    if (ULTRA_Structure.IRQ_Time > 1 || TIM4->CNT > BLIND_TIME) {
      TIM4->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN)); //关闭计数
      EXTI->IMR &= ~EXTI_Line11; //关闭11线的外部中断
      ULTRA_EchoHandler();
    }
    EXTI->PR = EXTI_Line11;
  }
}
