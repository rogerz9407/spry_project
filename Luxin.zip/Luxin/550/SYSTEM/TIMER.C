#include "timer.h"

void TIM_Configuration(void) {
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  //	TIM_ICInitTypeDef	 TIM_ICInitStructure;

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 |
                             RCC_APB1Periph_TIM4,
                         ENABLE);                 // 时钟使能TIM2
  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure); //初始化结构体
  // TIM2作为基准定时器产生1ms中断！可拿来当时钟以及主程序任务切换
  TIM_DeInit(TIM2);
  TIM_TimeBaseStructure.TIM_Period = 999;   // 1000/1000=1k
  TIM_TimeBaseStructure.TIM_Prescaler = 71; // 72/72=1m

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
  TIM2->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
  TIM_Cmd(TIM2, ENABLE);

  // TIM3作为超声波的驱动发生器
  TIM_DeInit(TIM3);

  TIM_TimeBaseStructure.TIM_Period = 239; // 36000/240/2=75khz
  TIM_TimeBaseStructure.TIM_Prescaler = 1; // 36m

  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  TIM3->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
  TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

  // TIM4作为超声波的回波时间计数器
  TIM_DeInit(TIM4);
  TIM_TimeBaseStructure.TIM_Period = 45000; // 45ms中断
  TIM_TimeBaseStructure.TIM_Prescaler = 71; // 1us

  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  TIM4->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
}
