//协议文件
//包含了参数处理，存储读取等功能

#include "protocol.h"

//上传时间
const uint16_t UPTIME[5] = {15, 30, 60, 120, 300};

PROTOCOL_TypeDef PROTOCOL_Structure;

//从FLASH读一整页时，若使用局部变量，会导致栈溢出！
//使用全局变量可解决！
uint8_t FLASH_RW_Buf[400] = {0};

void PROTOCOL_StructInit(void) {
  PROTOCOL_Structure.Device_ID[0] = '0';    //设备ID
  PROTOCOL_Structure.Device_ID[1] = '1';    //设备ID
  PROTOCOL_Structure.Device_ID[2] = 0;      //设备ID
  PROTOCOL_Structure.Contain_Height = 2000; //探测距离
  PROTOCOL_Structure.UPload_Time = 15;      //上传时间
}

//输出所有的设置信息
// OPT为选项字，为0的则直接串口输出
//为其他则会转存在FLASH_RW_Buf数组中
void PROTOCOL_SendAllConf(uint8_t OPT) {
  sprintf((char *)FLASH_RW_Buf,
          "ID: %s\r\nContain Height: %d\r\nUpload Time: %ds\r\n",
          PROTOCOL_Structure.Device_ID, PROTOCOL_Structure.Contain_Height,
          PROTOCOL_Structure.UPload_Time);
  if (OPT == 0) {
    USART_SendString(USART1, FLASH_RW_Buf, 0);
  }
}

//将基本配置信息写入FLASH中
uint8_t PROTOCOL_WriteBasicOPt(void) {
  //  B ID 高度 X Y 类型 时间 安装高度
  sprintf((char *)FLASH_RW_Buf, "B%s:%d:%d:", PROTOCOL_Structure.Device_ID,
          PROTOCOL_Structure.Contain_Height, PROTOCOL_Structure.UPload_Time);
  // printf("\r\n%s\r\n\r\n", Buf);
  FLASH_WriteString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf,
                    strlen((char *)FLASH_RW_Buf));
  return 1;
}

//从FLASH中读出基本配置的内容
uint8_t PROTOCOL_ReadBasicOPt(void) {
  PROTOCOL_StructInit(); //对结构体初始化
  FLASH_ReadString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf, 100);
  // printf("\r\n%s\r\n\r\n", FLASH_RW_Buf);
  if (FLASH_RW_Buf[0] == 'B') { //首字母为B 表明读出正常
    sscanf((char *)FLASH_RW_Buf, "B%2s:%d:%d:", PROTOCOL_Structure.Device_ID,
           &PROTOCOL_Structure.Contain_Height, &PROTOCOL_Structure.UPload_Time);
    PROTOCOL_SendAllConf(0);
    return 1;
  } else {                    //读出失败
    PROTOCOL_WriteBasicOPt(); //写入FLASH 中
    return 0;
  }
}

//读出设备当前ID
//传出数组
void PROTOCOL_ReadDeviceID(uint8_t *DvcID) {
  DvcID[0] = PROTOCOL_Structure.Device_ID[0];
  DvcID[1] = PROTOCOL_Structure.Device_ID[1];
}
//设置设备ID
//传入数组，不检查
void PROTOCOL_WriteDeviceID(uint8_t *DvcID) {
  PROTOCOL_Structure.Device_ID[0] = DvcID[0];
  PROTOCOL_Structure.Device_ID[1] = DvcID[1];
  PROTOCOL_WriteBasicOPt();
}
//读出探测高度 单位mm
uint16_t PROTOCOL_ReadContainHeight(void) {
  return PROTOCOL_Structure.Contain_Height;
}
//设置探测高度 单位mm
//超出范围不写入
void PROTOCOL_WriteContainHeight(uint16_t Height) {
  if (Height > 200 && Height < 30000) {
    PROTOCOL_Structure.Contain_Height = Height;
    PROTOCOL_WriteBasicOPt();
  }
}
//读出上传时间
uint16_t PROTOCOL_ReadUPTime(void) { return PROTOCOL_Structure.UPload_Time; }
//设置上传时间
//超出范围不写入
void PROTOCOL_WriteUPTime(uint16_t UPTime) {
  if (UPTime > 10 && UPTime <= 300) {
    PROTOCOL_Structure.UPload_Time = UPTime;
    PROTOCOL_WriteBasicOPt();
  }
}

//读取当前液体高度 单位mm
void PROTOCOL_ReadLiquidHeight(uint16_t *LiquidHeight) {
  ULTRA_ReadAirHeight(LiquidHeight);
  if (*LiquidHeight > PROTOCOL_Structure.Contain_Height || *LiquidHeight == 0) {
    *LiquidHeight = 0;
  } else {
    *LiquidHeight = PROTOCOL_Structure.Contain_Height - *LiquidHeight;
  }
}

//读取当前液体百分比  格式 XXX 对应 XXX%
void PROTOCOL_ReadPercent(uint16_t *Percent) {
  uint16_t LHeight;
  PROTOCOL_ReadLiquidHeight(&LHeight);
  *Percent = 100 * LHeight / (PROTOCOL_Structure.Contain_Height);
  if (*Percent > 100) {
    *Percent = 100;
  }
}

//计算传入数据的校验和
//直接返回计算的8位数值 不处理！
uint8_t PROTOCOL_CalcCheckSum(uint8_t *Data_In, uint16_t Data_Len) {
  uint16_t i = 0;
  uint8_t Sum_Data = 0;
  if (Data_Len < 5) {
    return 0; //太短 不计算
  }
  for (i = 0; i < Data_Len; i++) {
    Sum_Data = (uint8_t)(Sum_Data + Data_In[i]);
  }
  return Sum_Data;
}

//协议的校验和检查
//只能输入$************XX格式 XX为校验和
uint8_t PROTOCOL_CheckSumCheck(uint8_t *Data_Check) {
  uint16_t Data_Len = 0;
  uint8_t Sum_Data[2] = {0};
  Data_Len = strlen((char *)Data_Check);
  if (Data_Len < 7 || Data_Len > 200) { //短或长了
    return 0;
  }
  Sum_Data[0] = PROTOCOL_CalcCheckSum(Data_Check, Data_Len - 2);
  sprintf((char *)Sum_Data, "%02X", Sum_Data[0]); //转到数组里
  if ((Sum_Data[0] == Data_Check[Data_Len - 2]) &&
      (Sum_Data[1] == Data_Check[Data_Len - 1])) {
    return 1;
  }
  USART_SendString(USART1, "WRONG CHECKSUM   ", 0);
  USART_SendString(USART1, Sum_Data, 2);
  USART_SendString(USART1, "\r\n", 2);
  return 0;
}

//检查输入参数的ID
//输入的指针指向$
uint8_t PROTOCOL_IDCheck(uint8_t *ID_Check) {
  ID_Check += 3;
  if (ID_Check[0] == '0' && ID_Check[1] == '0') {
    return 1;
  }
  if (ID_Check[0] == PROTOCOL_Structure.Device_ID[0] &&
      ID_Check[1] == PROTOCOL_Structure.Device_ID[1]) {
    return 1;
  } else {
    return 0;
  }
}

//特殊指令处理
void PROTOCOL_SPecComDeal(uint8_t *Comm_Data) {
  if (strstr((char *)Comm_Data, "#SYSTEM RESTART NOW#") != NULL) {
    __set_FAULTMASK(1); // 关闭所有中端
    NVIC_SystemReset(); // 复位
  }
  if (strstr((char *)Comm_Data, "#SYSTEM RESTORE NOW#") != NULL) {
    PROTOCOL_StructInit();
    PROTOCOL_WriteBasicOPt();
  }
}

// RA RL RV RP几个参数的内容计算整理
//配合PROTOCOL_InforProcessRead使用
//传入的是R的地址 直接覆盖ID数据等信息
uint8_t PROTOCOL_ProReadCal(uint8_t *Data_P, uint8_t T, uint8_t Source) {
  uint16_t DataToRead;
  uint32_t DataToSend;
  switch (T) {
  case 1: //空气高度
    ULTRA_ReadAirHeight(&DataToRead);
    DataToSend = DataToRead;
    break;
  case 2: //液体高度
    PROTOCOL_ReadLiquidHeight(&DataToRead);
    DataToSend = DataToRead;
    break;
  case 4: //百分比
    PROTOCOL_ReadPercent(&DataToRead);
    DataToSend = DataToRead;
    break;
  default:
    break;
  }
  memset(FLASH_RW_Buf, 0, 20);
  if (T == 3) {
    sprintf((char *)FLASH_RW_Buf, "*%.2s%s%08d", Data_P,
            PROTOCOL_Structure.Device_ID, DataToSend);
  } else {
    sprintf((char *)FLASH_RW_Buf, "*%.2s%s%06d", Data_P,
            PROTOCOL_Structure.Device_ID, DataToSend);
  }
  sprintf((char *)FLASH_RW_Buf, "%s%02X\r\n", FLASH_RW_Buf,
          PROTOCOL_CalcCheckSum(FLASH_RW_Buf, strlen((char *)FLASH_RW_Buf)));
  if (Source == SRCUART) {
    USART_SendString(USART1, FLASH_RW_Buf, 0);
    USART_Send485Data(FLASH_RW_Buf, 0);
    return 1;
  } else {
    strcpy((char *)Data_P, (char *)FLASH_RW_Buf);
    return 1;
  }
}

//处理R开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是R所在的地址
uint8_t PROTOCOL_InforProcessRead(uint8_t *Read_Data, uint8_t Source) {

  Read_Data++; //加到下一位
  switch (*Read_Data) {
  case 'C':                  //读取配置
    if (Source == SRCUART) { //串口
      PROTOCOL_SendAllConf(0);
      return 1;
    } else { //其他
      Read_Data--;
      PROTOCOL_SendAllConf(1);
      memcpy(Read_Data, FLASH_RW_Buf, strlen((char *)FLASH_RW_Buf));
      return 1;
    }
  case 'A': //读取空气高度
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 1, Source); //计算空气高度
    return 1;
  case 'L': //读取液面高度
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 2, Source);
    return 1;
  case 'P': //读取百分比
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 4, Source);
    return 1;
  default:
    break;
  }
  return 0;
}

//处理S开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是S所在的地址
//若传入的来源为非串口，则会改写从S开始的内容为传出的内容。
uint8_t PROTOCOL_InforProcessSet(uint8_t *Set_Data, uint8_t Source) {
  uint8_t Buf[10] = {0}; //转参数时中间数组
  Set_Data++;            //到下一位
  switch (*Set_Data) {
  case 'I': //设置ID
    Set_Data += 7;
    PROTOCOL_WriteDeviceID(Set_Data);
    sprintf((char *)FLASH_RW_Buf, "ID: %s\r\n", PROTOCOL_Structure.Device_ID);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 8;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'H': //设置高度
    Set_Data += 3;
    memcpy(Buf, Set_Data, 6);
    PROTOCOL_WriteContainHeight(atoi((char *)Buf));
    sprintf((char *)FLASH_RW_Buf, "Height: %d\r\n",
            PROTOCOL_Structure.Contain_Height);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 4;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  default:
    return 0;
  }
  return 1;
}

//传入的协议信息处理
//参数Para为是否判断ID 校验和等。
//参数Source为判断来源，有些指令来源错误不判断
//先判断$ 后判断是否校验和ID 都正常才进流程
//若处理正常，会返回$所在的地址，否则返回NULL
uint8_t *PROTOCOL_InforProcess(uint8_t *Protocol_Data, uint8_t Para,
                               uint8_t Source) {
  uint8_t *ptr1;
  uint8_t i = 0;
  ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '$'); //查找起始符
  if (ptr1 == NULL) {                                   //没找到
    ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '#');
    if (ptr1 != NULL) {
      PROTOCOL_SPecComDeal(Protocol_Data);
    }
    return NULL; // NOSTRCR; //返回错误
  }
  if ((Para & NOCKSCHK) == 0) {              //需要检查校验和
    if (PROTOCOL_CheckSumCheck(ptr1) == 0) { //检查校验和
      return NULL;                           // CHKWRNG;
    }
  }
  if ((Para & NOIDCHK) == 0) {         //需要检查ID
    if (PROTOCOL_IDCheck(ptr1) == 0) { //检查ID
      return NULL;                     // IDWRONG;
    }
  }
  ptr1++;
  switch (*ptr1) {
  case 'R': //读取指令
    i = PROTOCOL_InforProcessRead(ptr1, Source);
    if (i == 1) {
      return ptr1;
    } else {
      return NULL;
    }
  case 'S': //设置指令
    i = PROTOCOL_InforProcessSet(ptr1, Source);
    if (i == 1) {
      return ptr1;
    } else {
      return NULL;
    }
  case 'U': //上传时间
    ptr1++;
    if (*ptr1 == 'T') { //是T
      ptr1 += 8;
      if (*ptr1 > 0x30) {
        PROTOCOL_WriteUPTime(UPTIME[*ptr1 - 0x31]);
        sprintf((char *)FLASH_RW_Buf, "UPload_Time: %ds\r\n",
                PROTOCOL_Structure.UPload_Time);
        if (Source == SRCUART) { //来自串口，直接打印
          USART_SendString(USART1, FLASH_RW_Buf, 0);
          USART_Send485Data(FLASH_RW_Buf, 0);
          return NULL;
        } else { //其他情况会写入数组中
          ptr1 -= 10;
          strcpy((char *)ptr1, (char *)FLASH_RW_Buf);
          return ptr1;
        }
      } else {
        break;
      }
    }
  default:
    return NULL;
  }
  return NULL;
}

//刷新发送数据
uint8_t PROTOCOL_RefreshData(void) {
  // uint16_t LH, PT;
  uint16_t AH;
  memset(FLASH_RW_Buf, 0, 200);
  // PROTOCOL_ReadLiquidHeight(&LH);
  // PROTOCOL_ReadPercent(&PT);
  // DAC_SetOutData(PT);
  ULTRA_ReadAirHeight(&AH);
  sprintf((char *)FLASH_RW_Buf, "*RA%s%06d", PROTOCOL_Structure.Device_ID, AH);
  sprintf((char *)FLASH_RW_Buf, "%s%02X\r\n", FLASH_RW_Buf,
          PROTOCOL_CalcCheckSum(FLASH_RW_Buf, 11));
  USART_SendString(USART1, FLASH_RW_Buf, 15);
  USART_SendString(USART3, FLASH_RW_Buf, 15);
  return 1;
}
