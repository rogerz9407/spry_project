//存放一些计算函数

#include "calct.h"

const double PI = 3.1415926;

//查找数组中最大的数
uint16_t Find_Biggest(uint16_t *arr, uint16_t len) {
  uint16_t i;
  uint32_t Big_Number = 0;
  for (i = 0; i < len; i++) {
    if (Big_Number < arr[i]) {
      Big_Number = arr[i];
    }
  }
  return (uint16_t)Big_Number;
}

//求得对应数组的平均值
uint32_t Get_Average(uint32_t *arr, uint16_t len) {
  uint16_t i;
  uint32_t Sum = 0;
  for (i = 0; i < len; i++) {
    Sum += arr[i];
  }
  Sum /= len;
  return Sum;
}

//交换位置
void swap(uint32_t *x, uint32_t *y) {
  uint32_t t = *x;
  *x = *y;
  *y = t;
}

//冒泡排序
void Bubble_Sort(uint32_t *arr, uint32_t len) {
  uint32_t i, j;
  for (i = 0; i < len - 1; i++)
    for (j = 0; j < len - 1 - i; j++)
      if (arr[j] > arr[j + 1]) {
        swap(&arr[j], &arr[j + 1]);
      }
}

//寻找出现次数最多的数
uint32_t Find_Most(uint32_t *arr, uint32_t len) {
  uint32_t i, temp = 0, Most_Number;
  uint32_t time1 = 0, time2 = 0;
  temp = arr[0];
  Most_Number = temp;
  for (i = 1; i < len; i++) {
    if (arr[i] == temp)
      time2++;
    else {
      if (time2 > time1) {
        time1 = time2;
        time2 = 0;
        Most_Number = temp;
        if (time1 > len / 2)
          break;
      }
      temp = arr[i];
    }
  }
  return Most_Number;
}

//计算整数的绝对值
uint32_t MYabs(uint32_t B_Num, uint32_t L_Num) {
  if (B_Num < L_Num)
    return (L_Num - B_Num);
  else
    return (B_Num - L_Num);
}
