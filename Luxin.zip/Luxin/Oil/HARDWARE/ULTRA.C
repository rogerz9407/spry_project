//超声波控制等函数
#include "ultra.h"

ULTRA_TypeDef ULTRA_Structure;

uint8_t ULTRA_Send_Count = 0;
uint32_t Multi_Time[5], Normal_Read[5], Final_Read[80];
double Multi_Width[5];
uint8_t Multi_Count = 0;
uint8_t Normal_Count = 0;
uint16_t Final_Count = 20;
uint32_t Multi_Temp, Final_Temp, Count_Temp;

void ULTRA_StructInit(void) {
  uint8_t i;
  memset(ULTRA_Structure.Echo_Time, 0, 40); //回波时间 单位us
  ULTRA_Structure.Echo_Count = 0;           //回波数量计算
  ULTRA_Structure.IRQ_Count = 0;            // TIM4计数的次数
  ULTRA_Structure.Average_Time = 0;         //平均时间
  for (i = 0; i < 20; i++)
    Final_Read[i] = 600;
}

//超声波开启定时器启动探头进行测量
void ULTRA_StartDetect(void) {
  uint8_t i;
  uint16_t Big = 0;
  ULTRA_Structure.IRQ_Count = 0;

  TIM3->CR1 |= TIM_CR1_CEN; //打开中断
  while (ULTRA_Structure.IRQ_Count < 150)//350)
    ;
  while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_11))
    ;
  while (ULTRA_Structure.IRQ_Count < 6000){//3500) {
    if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_11)) {
      Multi_Time[Multi_Count] = ULTRA_Structure.IRQ_Count + 100;
      DMA_Cmd(DMA1_Channel1, ENABLE); //开DMA
      while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_11))
        ;
      DMA_Cmd(DMA1_Channel1, DISABLE); //关DMA
      Big = Find_Biggest(AD_Value, 400);
      Multi_Width[Multi_Count++] = Big * 0.0016;
      for (Big = 0; Big < 400; Big++) {
        AD_Value[Big] = 0;
      }
      delay_us(1000);
    }
    if (Multi_Count == 5) {
      break;
    }
  }
  TIM4->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN)); //关闭计数
  ULTRA_Structure.IRQ_Count = 0;
  if (Multi_Count == 0) {
    printf("No Echo\r\n");
    goto end;
  }
  Normal_Read[Normal_Count] = Multi_Time[0]; //赋初值
  // for (i = 0; i < Multi_Count - 1; i++) {
  //   // Multi_Temp = MYabs(Multi_Time[i + 1], Multi_Time[i] * 2);
  //   if (Multi_Temp < 150) {
  //     Normal_Read[Normal_Count] = Multi_Time[i];
  //     break;
  //   }
  //   if (i == (Multi_Count - 2))
  //     Normal_Read[Normal_Count] = Multi_Time[i + 1];
  // }
  Multi_Temp = Multi_Width[0];
  for (i = 0; i < Multi_Count; i++) {
    if (Multi_Temp < Multi_Width[i]) {
      Multi_Temp = Multi_Width[i];
      Normal_Read[Normal_Count] = Multi_Time[i];
    }
  }
  printf("Multi_Read: \r\n");
  for (i = 0; i < Multi_Count; i++) {
    printf("%.3f  %d \r\n", Multi_Width[i], (uint16_t)(Multi_Time[i] * 1.7));
    Multi_Time[i] = 0;
    Multi_Width[i] = 0.0;
  }
  Multi_Count = 0;
  // printf("\r\n");

  Normal_Count++;
  if (Normal_Count == 5) {
    Bubble_Sort(Normal_Read, 5);
    Final_Read[Final_Count] = Normal_Read[2];
    Final_Count++;
    printf("Normal_Read: ");
    for (i = 0; i < Normal_Count; i++) {
      printf("%d ", (uint32_t)(Normal_Read[i] * 1.7));
      Normal_Read[i] = 0;
    }
    Normal_Count = 0;
    printf("\r\n");
  }

  if (Final_Count >= 80) {
    Final_Count = 20;
    Final_Temp = 0;
    Count_Temp = 0;
    Bubble_Sort(Final_Read, 80);
    for (i = 30; i < 50; i++) {
      // printf("%d ",(uint32_t)(Final_Read[i]*1.7));
      Final_Temp += Final_Read[i];
      Final_Read[i - 30] = Final_Read[i];
    }
    Final_Temp /= 20;
    ULTRA_Structure.Average_Time = 1.7 * Final_Temp;
    ULTRA_Structure.Average_Time = ULTRA_Structure.Average_Time * 1.196 - 117.4;
  }
end:
  return;
}

//返回当前测得的空气高度
//返回16位数据，单位为mm
void ULTRA_ReadAirHeight(uint16_t *Air_Height) {
  // float Temperature;
  //先读取当前温度
  // NTC_GetTemperature(&Temperature);
  *Air_Height = ULTRA_Structure.Average_Time;
}

// TIM3中断驱动超声波
void TIM3_IRQHandler(void) {
  if (TIM3->SR & TIM_IT_Update) {
    TIM3->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
    ULTRA_Send_Count++;
    if (ULTRA_Send_Count <= ULTRACOUNT) {
      if (ULTRA_Send_Count % 2 == 0) {
        GPIOB->BSRR = GPIO_Pin_8;
      } else {
        GPIOB->BRR = GPIO_Pin_8;
      }
    } else {
      TIM3->CR1 &= (uint16_t)(~((uint16_t)TIM_CR1_CEN)); //关闭计数
      ULTRA_Send_Count = 0;
      TIM4->CNT = 0;
      TIM4->CR1 |= TIM_CR1_CEN; //打开中断
    }
  }
}

// TIM4 中断回波时间计算
void TIM4_IRQHandler(void) {
  if (TIM4->SR & TIM_IT_Update) {
    TIM4->SR = (uint16_t)~TIM_IT_Update; //清除中断标志
    ULTRA_Structure.IRQ_Count++;
  }
}
