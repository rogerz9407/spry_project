//协议文件
//包含了参数处理，存储读取等功能

#include "protocol.h"

//上传时间
const uint16_t UPTIME[5] = {15, 30, 60, 120, 300};

PROTOCOL_TypeDef PROTOCOL_Structure;

//从FLASH读一整页时，若使用局部变量，会导致栈溢出！
//使用全局变量可解决！
uint8_t FLASH_RW_Buf[200] = {0};

void PROTOCOL_StructInit(void) {
  PROTOCOL_Structure.Device_ID[0] = '0';    //设备ID
  PROTOCOL_Structure.Device_ID[1] = '1';    //设备ID
  PROTOCOL_Structure.Device_ID[2] = 0;      //设备ID
  PROTOCOL_Structure.Contain_Height = 2000; //探测距离
  PROTOCOL_Structure.X_Value = 1000;        // X值
  PROTOCOL_Structure.Y_Value = 1000;        // Y值
  PROTOCOL_Structure.Contain_Type = 1;      //容器类型
  PROTOCOL_Structure.UPload_Time = 15;      //上传时间
  PROTOCOL_Structure.Liquid_Type = 0;       //默认为0
  PROTOCOL_Structure.Liquid_Speed = 1.48;   //默认设为水的
  PROTOCOL_Structure.Speed_coeef = 0.002;   //几乎不变
}

//输出所有的设置信息
void PROTOCOL_SendAllConf(uint8_t OPT) {
  sprintf((char *)FLASH_RW_Buf,
          "ID: %s\r\nContain Height: %d\r\nX Value: %d\r\nY "
          "Value: %d\r\nContain Type: %d\r\nUpload Time: %ds\r\n"
          "Liquid Type: %d\r\nLiquid Speed: %.3lf\r\n",
          PROTOCOL_Structure.Device_ID, PROTOCOL_Structure.Contain_Height,
          PROTOCOL_Structure.X_Value, PROTOCOL_Structure.Y_Value,
          PROTOCOL_Structure.Contain_Type, PROTOCOL_Structure.UPload_Time,
          PROTOCOL_Structure.Liquid_Type, PROTOCOL_Structure.Liquid_Speed);
  if (OPT == 0) {
    USART_SendString(USART1, FLASH_RW_Buf, 0);
    // USART_Send485Data(FLASH_RW_Buf, 0);
  }
}

//将基本配置信息写入FLASH中
uint8_t PROTOCOL_WriteBasicOPt(void) {
  //  B ID 高度 X Y 类型 时间 安装高度
  memset(FLASH_RW_Buf, 0, 200);
  sprintf((char *)FLASH_RW_Buf, "BASIC:%s:%d:%d:%d:%d:%d:%d:%lf:%lf:",
          PROTOCOL_Structure.Device_ID, PROTOCOL_Structure.Contain_Height,
          PROTOCOL_Structure.X_Value, PROTOCOL_Structure.Y_Value,
          PROTOCOL_Structure.Contain_Type, PROTOCOL_Structure.UPload_Time,
          PROTOCOL_Structure.Liquid_Type, PROTOCOL_Structure.Liquid_Speed,
          PROTOCOL_Structure.Speed_coeef);
  // USART_Send485Data("\r\n\r\n", 4);
  // USART_Send485Data("Write: ", 7);
  // USART_Send485Data(FLASH_RW_Buf, 0);
  // USART_Send485Data("\r\n\r\n", 4);
  FLASH_WriteString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf,
                    strlen((char *)FLASH_RW_Buf));
  return 1;
}

//从FLASH中读出基本配置的内容
uint8_t PROTOCOL_ReadBasicOPt(void) {
  uint16_t i, j;
  PROTOCOL_StructInit(); //对结构体初始化
  FLASH_ReadString(BASIC_OPTION_ADDR, (uint16_t *)FLASH_RW_Buf, 200);
  // printf("\r\n%s\r\n\r\n", FLASH_RW_Buf);
  // USART_Send485Data("Read: ", 6);
  // USART_Send485Data(FLASH_RW_Buf, 400);
  // USART_Send485Data("\r\n\r\n", 4);
  if (FLASH_RW_Buf[0] == 'B' &&
      (strstr((char *)FLASH_RW_Buf, "BASIC:") != NULL)) {
    // sscanf((char *)FLASH_RW_Buf, "BASIC:%[^:]:%d:%d:%d:%d:%d:%d:%lf:%lf:",
    //        PROTOCOL_Structure.Device_ID, &PROTOCOL_Structure.Contain_Height,
    //        &PROTOCOL_Structure.X_Value, &PROTOCOL_Structure.Y_Value,
    //        &PROTOCOL_Structure.Contain_Type, &PROTOCOL_Structure.UPload_Time,
    //        &PROTOCOL_Structure.Liquid_Type, &PROTOCOL_Structure.Liquid_Speed,
    //        &PROTOCOL_Structure.Speed_coeef);
    PROTOCOL_Structure.Device_ID[0] = FLASH_RW_Buf[6];
    PROTOCOL_Structure.Device_ID[1] = FLASH_RW_Buf[7];
    PROTOCOL_Structure.Device_ID[2] = 0;
    i = 9;
    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.Contain_Height = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.X_Value = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.Y_Value = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.Contain_Type = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.UPload_Time = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      j = j * 10 + FLASH_RW_Buf[i++] - 0x30;
    }
    PROTOCOL_Structure.Liquid_Type = j;
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      FLASH_RW_Buf[j + 200] = FLASH_RW_Buf[i++];
      j++;
    }
    FLASH_RW_Buf[j + 200] = 0;
    PROTOCOL_Structure.Liquid_Speed = atof((char *)&FLASH_RW_Buf[200]);
    i++;

    j = 0;
    while (FLASH_RW_Buf[i] != ':') {
      FLASH_RW_Buf[j + 200] = FLASH_RW_Buf[i++];
    }
    FLASH_RW_Buf[j + 200] = 0;
    PROTOCOL_Structure.Speed_coeef = atof((char *)&FLASH_RW_Buf[200]);

    PROTOCOL_SendAllConf(0);
    return 1;
  } else {                    //读出失败
    PROTOCOL_StructInit();    //对结构体初始化
    PROTOCOL_WriteBasicOPt(); //写入FLASH 中
    return 0;
  }
}

//读出设备当前ID
//传出数组
void PROTOCOL_ReadDeviceID(uint8_t *DvcID) {
  DvcID[0] = PROTOCOL_Structure.Device_ID[0];
  DvcID[1] = PROTOCOL_Structure.Device_ID[1];
}
//设置设备ID
//传入数组，不检查
void PROTOCOL_WriteDeviceID(uint8_t *DvcID) {
  PROTOCOL_Structure.Device_ID[0] = DvcID[0];
  PROTOCOL_Structure.Device_ID[1] = DvcID[1];
  PROTOCOL_WriteBasicOPt();
}
//读出探测高度 单位mm
uint16_t PROTOCOL_ReadContainHeight(void) {
  return PROTOCOL_Structure.Contain_Height;
}
//设置探测高度 单位mm
//超出范围不写入
void PROTOCOL_WriteContainHeight(uint16_t Height) {
  if (Height > 50 && Height <= 2000) {
    PROTOCOL_Structure.Contain_Height = Height;
    PROTOCOL_WriteBasicOPt();
  }
}
//读出X值 单位mm
uint16_t PROTOCOL_ReadXValue(void) { return PROTOCOL_Structure.X_Value; }
//写入X值 单位mm
void PROTOCOL_WriteXValue(uint16_t XValue) {
  PROTOCOL_Structure.X_Value = XValue;
  PROTOCOL_WriteBasicOPt();
}
//读出Y值 单位mm
uint16_t PROTOCOL_ReadYValue(void) { return PROTOCOL_Structure.Y_Value; }
//写入Y值 单位mm
void PROTOCOL_WriteYValue(uint16_t YValue) {
  PROTOCOL_Structure.Y_Value = YValue;
  PROTOCOL_WriteBasicOPt();
}
//读出容器类型
uint8_t PROTOCOL_ReadConType(void) { return PROTOCOL_Structure.Contain_Type; }
//设置容器类型
void PROTOCOL_WriteConType(uint8_t Type) {
  if (Type > 0 && Type < 4) {
    PROTOCOL_Structure.Contain_Type = Type;
    PROTOCOL_WriteBasicOPt();
  }
}
//读出上传时间
uint16_t PROTOCOL_ReadUPTime(void) { return PROTOCOL_Structure.UPload_Time; }
//设置上传时间
//超出范围不写入
void PROTOCOL_WriteUPTime(uint16_t UPTime) {
  if (UPTime > 10 && UPTime <= 300) {
    PROTOCOL_Structure.UPload_Time = UPTime;
    PROTOCOL_WriteBasicOPt();
  }
}
//读出当前的液体速度常数值
double PROTOCOL_ReadLiquidSpeed(void) {
  return PROTOCOL_Structure.Liquid_Speed;
}
//设置液体速度的常数值
//将覆盖设置类型中的参数
void PROTOCOL_SetliquidSpeed(double SPEED) {
  if (SPEED > 0) {
    PROTOCOL_Structure.Liquid_Speed = SPEED;
    PROTOCOL_Structure.Speed_coeef = 0.002; //系数值 差异小 默认值
    PROTOCOL_Structure.Liquid_Type = 0;     //清除设置的液体类型
    PROTOCOL_WriteBasicOPt();
  }
}
//读出当前液体类型
//若已经另外设置了速度，则该值无效
uint8_t PROTOCOL_ReadLiquidType(void) { return PROTOCOL_Structure.Liquid_Type; }
//设置液体类型
//将覆盖设置的速度
void PROTOCOL_SetLiquidType(uint8_t TYPE) {
  if (TYPE > 0 && TYPE < 4) {
    PROTOCOL_Structure.Liquid_Type = TYPE;
    switch (PROTOCOL_Structure.Liquid_Type) {
    case 1: //水
      PROTOCOL_Structure.Liquid_Speed = 1.48;
      PROTOCOL_Structure.Speed_coeef = 0.002;
      break;
    case 2: //汽油
      PROTOCOL_Structure.Liquid_Speed = 1.139;
      PROTOCOL_Structure.Speed_coeef = 0.0019;
      break;
    case 3: //柴油
      PROTOCOL_Structure.Liquid_Speed = 1.385;
      PROTOCOL_Structure.Speed_coeef = 0.002;
      break;
    default:
      break;
    }
    PROTOCOL_WriteBasicOPt();
  }
}

//读取液体的高度
void PROTOCOL_ReadLiQuidHeight(uint16_t *LDHeight) {
  float Speed;
  float Temperature;

  sprintf((char *)FLASH_RW_Buf, "Tem: %.3f\r\n", Temperature);
  // USART_Send485Data(FLASH_RW_Buf, 0);
  // USART_SendString(USART1, FLASH_RW_Buf, 0);
  if (Temperature < -35.0 || Temperature > 120) {
    Temperature = 24.0;
  }
  Speed = PROTOCOL_Structure.Liquid_Speed +
          PROTOCOL_Structure.Speed_coeef * (Temperature - 20.0); //速度计算
  //计算高度
  // printf("Liquid:%d\r\n", *LDHeight);
  if (*LDHeight >
      PROTOCOL_Structure.Contain_Height) { //计算得到空气高度大于了最大高度
    *LDHeight = PROTOCOL_Structure.Contain_Height;
  }
}

//读取当前的体积 单位L
float PROTOCOL_ReadVolume(void) {
  uint16_t LHeight = 0;
  double BottomArea = 0.0;
  double Radius = 0.0;                 //半径
  PROTOCOL_ReadLiQuidHeight(&LHeight); //先读出液体高度
  switch (PROTOCOL_Structure.Contain_Type) {
  case 1: //竖直的圆柱
    BottomArea = CAL_CircleArea(PROTOCOL_Structure.X_Value / 100.0,
                                PROTOCOL_Structure.Y_Value / 100.0);
    BottomArea *= LHeight / 100.0;
    break;
  case 2: //放倒的圆柱
    Radius = PROTOCOL_Structure.X_Value / 200.0;
    CAL_ArcuateArea(Radius, LHeight / 100.0, &BottomArea); //计算的弓形面积
    BottomArea *= PROTOCOL_Structure.Y_Value / 100.0;      //乘以长度
    break;
  case 3: //立方体
          //底面积平方分米
    BottomArea = PROTOCOL_Structure.X_Value / 100.0;
    BottomArea *= PROTOCOL_Structure.Y_Value / 100.0;
    BottomArea *= LHeight / 100.0;
    break;
  default:
    break;
  }
  if (BottomArea > 99999999) {
    return 99999999;
  }
  return BottomArea;
}

//读取当前液体百分比  格式 XXX 对应 XXX%
void PROTOCOL_ReadPercent(uint16_t *Percent) {
  uint16_t LHeight;
  PROTOCOL_ReadLiQuidHeight(&LHeight);
  *Percent = 100 * LHeight / PROTOCOL_Structure.Contain_Height;
  if (*Percent > 100) {
    *Percent = 100;
  }
}

//计算传入数据的校验和
//直接返回计算的8位数值 不处理！
uint8_t PROTOCOL_CalcCheckSum(uint8_t *Data_In, uint16_t Data_Len) {
  uint16_t i = 0;
  uint8_t Sum_Data = 0;
  if (Data_Len < 5) {
    return 0; //太短 不计算
  }
  for (i = 0; i < Data_Len; i++) {
    Sum_Data = (uint8_t)(Sum_Data + Data_In[i]);
  }
  return Sum_Data;
}

//协议的校验和检查
//只能输入$************XX格式 XX为校验和
uint8_t PROTOCOL_CheckSumCheck(uint8_t *Data_Check) {
  uint16_t Data_Len = 0;
  uint8_t Sum_Data[2] = {0};
  Data_Len = strlen((char *)Data_Check);
  if (Data_Len < 7 || Data_Len > 200) { //短或长了
    return 0;
  }
  Sum_Data[0] = PROTOCOL_CalcCheckSum(Data_Check, Data_Len - 2);
  sprintf((char *)Sum_Data, "%02X", Sum_Data[0]); //转到数组里
  if ((Sum_Data[0] == Data_Check[Data_Len - 2]) &&
      (Sum_Data[1] == Data_Check[Data_Len - 1])) {
    return 1;
  }
  USART_SendString(USART1, "WRONG CHECKSUM   ", 0);
  USART_SendString(USART1, Sum_Data, 2);
  USART_SendString(USART1, "\r\n", 2);
  // USART_Send485Data("WRONG CHECKSUM   ", 0);
  // USART_Send485Data(Sum_Data, 2);
  // USART_Send485Data("\r\n", 2);
  return 0;
}

//检查输入参数的ID
//输入的指针指向$
uint8_t PROTOCOL_IDCheck(uint8_t *ID_Check) {
  ID_Check += 3;
  if (ID_Check[0] == '0' && ID_Check[1] == '0') {
    return 1;
  }
  if (ID_Check[0] == PROTOCOL_Structure.Device_ID[0] &&
      ID_Check[1] == PROTOCOL_Structure.Device_ID[1]) {
    // USART_Send485Data(PROTOCOL_Structure.Device_ID, 2);
    // USART_Send485Data(" ", 1);
    return 1;
  } else {
    // USART_SendString(USART1, "WRONG ID\r\n", 10);
    // USART_Send485Data("WRONG ID\r\n", 10);
    return 0;
  }
}

//特殊指令处理
void PROTOCOL_SPecComDeal(uint8_t *Comm_Data) {
  if (strstr((char *)Comm_Data, "#SYSTEM RESTART NOW#") != NULL) {
    __set_FAULTMASK(1); // 关闭所有中端
    NVIC_SystemReset(); // 复位
  }
  if (strstr((char *)Comm_Data, "#SYSTEM RESTORE NOW#") != NULL) {
    PROTOCOL_StructInit();
    PROTOCOL_WriteBasicOPt();
  }
}

// RA RL RV RP几个参数的内容计算整理
//配合PROTOCOL_InforProcessRead使用
//传入的是R的地址 直接覆盖ID数据等信息
uint8_t PROTOCOL_ProReadCal(uint8_t *Data_P, uint8_t T, uint8_t Source) {
  uint8_t Send_Buf[20] = {0};
  uint16_t DataToRead;
  uint32_t DataToSend;
  switch (T) {
  case 2: //液体高度
    PROTOCOL_ReadLiQuidHeight(&DataToRead);
    DataToSend = DataToRead;
    break;
  case 3: //体积
    DataToSend = (uint32_t)PROTOCOL_ReadVolume();
    break;
  case 4: //百分比
    PROTOCOL_ReadPercent(&DataToRead);
    DataToSend = DataToRead;
    break;
  default:
    break;
  }
  if (T == 3) {
    sprintf((char *)Send_Buf, "*%.2s%s%08d", Data_P,
            PROTOCOL_Structure.Device_ID, DataToSend);
  } else {
    sprintf((char *)Send_Buf, "*%.2s%s%06d", Data_P,
            PROTOCOL_Structure.Device_ID, DataToSend);
  }
  sprintf((char *)Send_Buf, "%s%02X\r\n", Send_Buf,
          PROTOCOL_CalcCheckSum(Send_Buf, strlen((char *)Send_Buf)));
  if (Source == SRCUART) {
    USART_SendString(USART1, Send_Buf, 0);
    // USART_Send485Data(Send_Buf, 0);
    return 1;
  } else {
    strcpy((char *)Data_P, (char *)Send_Buf);
    return 1;
  }
}

//处理R开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是R所在的地址
uint8_t PROTOCOL_InforProcessRead(uint8_t *Read_Data, uint8_t Source) {

  Read_Data++; //加到下一位
  switch (*Read_Data) {
  case 'C':                  //读取配置
    if (Source == SRCUART) { //串口
      PROTOCOL_SendAllConf(0);
      return 1;
    } else { //其他
      Read_Data--;
      PROTOCOL_SendAllConf(1);
      memcpy(Read_Data, FLASH_RW_Buf, strlen((char *)FLASH_RW_Buf));
      return 1;
    }
  case 'L': //读取液面高度
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 2, Source);
    return 1;
  case 'V': //读取体积
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 3, Source);
    return 1;
  case 'P': //读取百分比
    Read_Data -= 1;
    PROTOCOL_ProReadCal(Read_Data, 4, Source);
    return 1;
  default:
    break;
  }
  return 0;
}

//处理S开头的指令，配合PROTOCOL_InforProcess函数用，不可单独用
//默认传入的是S所在的地址
//若传入的来源为非串口，则会改写从S开始的内容为传出的内容。
uint8_t PROTOCOL_InforProcessSet(uint8_t *Set_Data, uint8_t Source) {
  uint8_t Buf[10] = {0}; //转参数时中间数组
  Set_Data++;            //到下一位
  switch (*Set_Data) {
  case 'I': //设置ID
    Set_Data += 7;
    PROTOCOL_WriteDeviceID(Set_Data);
    sprintf((char *)FLASH_RW_Buf, "ID: %s\r\n", PROTOCOL_Structure.Device_ID);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      // USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 8;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'T': //设置容器类型
    Set_Data += 8;
    PROTOCOL_WriteConType(*Set_Data - 0x30);
    sprintf((char *)FLASH_RW_Buf, "Contain Type: %d\r\n",
            PROTOCOL_Structure.Contain_Type);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      // USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 9;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'L': //设置液体类型
    Set_Data += 8;
    //设置类型  1-水   2-汽油   3-柴油
    //实际也是转为速度和写入
    PROTOCOL_SetLiquidType(*Set_Data - 0x30);
    sprintf((char *)FLASH_RW_Buf, "Liquid Type: %d\r\n",
            PROTOCOL_Structure.Liquid_Type);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      // USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 9;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'S': //设置声波液体中速度
    Set_Data += 3;
    Set_Data[6] = 0;
    PROTOCOL_SetliquidSpeed(atof((char *)Set_Data));
    sprintf((char *)FLASH_RW_Buf, "Liquid Speed: %.3f\r\n",
            PROTOCOL_Structure.Liquid_Speed);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      // USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 9;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'H': //设置高度
    Set_Data += 3;
    memcpy(Buf, Set_Data, 6);
    PROTOCOL_WriteContainHeight(atoi((char *)Buf));
    sprintf((char *)FLASH_RW_Buf, "Height: %d\r\n",
            PROTOCOL_Structure.Contain_Height);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      //   USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 4;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'X': //设置X
    Set_Data += 3;
    memcpy(Buf, Set_Data, 6);
    PROTOCOL_WriteXValue(atoi((char *)Buf));
    sprintf((char *)FLASH_RW_Buf, "X_Value: %d\r\n",
            PROTOCOL_Structure.X_Value);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      //   USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 4;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  case 'Y': //设置Y
    Set_Data += 3;
    memcpy(Buf, Set_Data, 6);
    PROTOCOL_WriteYValue(atoi((char *)Buf));
    sprintf((char *)FLASH_RW_Buf, "Y_Value: %d\r\n",
            PROTOCOL_Structure.Y_Value);
    if (Source == SRCUART) { //来自串口，直接打印
      USART_SendString(USART1, FLASH_RW_Buf, 0);
      //   USART_Send485Data(FLASH_RW_Buf, 0);
      break;
    } else { //其他情况会写入数组中
      Set_Data -= 4;
      strcpy((char *)Set_Data, (char *)FLASH_RW_Buf);
      break;
    }
  default:
    return 0;
  }
  return 1;
}

//传入的协议信息处理
//参数Para为是否判断ID 校验和等。
//参数Source为判断来源，有些指令来源错误不判断
//先判断$ 后判断是否校验和ID 都正常才进流程
//若处理正常，会返回$所在的地址，否则返回NULL
uint8_t *PROTOCOL_InforProcess(uint8_t *Protocol_Data, uint8_t Para,
                               uint8_t Source) {
  uint8_t *ptr1;
  uint8_t i = 0;

  ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '$'); //查找起始符
  if (ptr1 == NULL) {                                   //没找到
    ptr1 = (uint8_t *)strchr((char *)Protocol_Data, '#');
    if (ptr1 != NULL) {
      PROTOCOL_SPecComDeal(Protocol_Data);
    }
    return NULL; // NOSTRCR; //返回错误
  }
  if ((Para & NOCKSCHK) == 0) {              //需要检查校验和
    if (PROTOCOL_CheckSumCheck(ptr1) == 0) { //检查校验和
      return NULL;                           // CHKWRNG;
    }
  }
  if ((Para & NOIDCHK) == 0) {         //需要检查ID
    if (PROTOCOL_IDCheck(ptr1) == 0) { //检查ID
      return NULL;                     // IDWRONG;
    }
  }
  ptr1++;
  switch (*ptr1) {
  
  default:
    return NULL;
  }
}

uint8_t PROTOCOL_RefreshData(void) {
  uint16_t LH, PT;
  memset(FLASH_RW_Buf, 0, 100);
  PROTOCOL_ReadLiQuidHeight(&LH);
  PROTOCOL_ReadPercent(&PT);
  USART_SendString(USART1, FLASH_RW_Buf, 15);
  return 1;
}
