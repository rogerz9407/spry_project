
#include "main.h"

uint32_t Milisec = 0;
uint32_t MAIN_Event = 0;

int main(void) {

  RCC_Configuration();  //时钟配置
  GPIO_Configuration(); // gpio配置
  NVIC_Configuration();
  USART_Configuration(); //串口配置
  delay_init();          // systick时钟配置
  TIM_Configuration();   //定时器配置
  //ADC_Configuration();
  //DMA_Configuration();
  delay_ms(1000);
  PROTOCOL_ReadBasicOPt();
  delay_ms(1000);

  IWDG_Init(6,2000);
  USART_SendString(USART1, "\r\nSYSTEM OK\r\n", 0);
  //USART_Send485Data("\r\nSYSTEM OK\r\n", 0);
  Milisec = 1;
  MAIN_Event = 0;
  while (1) {
    if (MAIN_Event & MAIN_STARTULTRA) {

      MAIN_Event ^= MAIN_STARTULTRA;
    }
    if (MAIN_Event & MAIN_REFRESHDATA) {

      MAIN_Event ^= MAIN_REFRESHDATA;
    }
    if (MAIN_Event & MAIN_CLEARCOUNT) {
      Milisec = 0;
      MAIN_Event ^= MAIN_CLEARCOUNT;
    }
    if (MAIN_Event & MAIN_SYSRESTART) {
      __set_FAULTMASK(1); // 关闭所有中端
      NVIC_SystemReset(); // 复位
    }
  }
}

void TIM4_IRQHandler(void) {
  if (TIM4->SR & TIM_IT_Update) {
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    Milisec++;
    if (Milisec % 678 == 0) {
      MAIN_Event |= MAIN_STARTULTRA;
    }
    if (Milisec % 1000 == 0) { // 1秒

        //MAIN_Event |= MAIN_REFRESHDATA;
    }
    if (Milisec % 4000 == 0) {
      IWDG->KR = (uint16_t)0xAAAA;
    }
    if (Milisec % 10000 == 0) {
      MAIN_Event |= MAIN_CLEARCOUNT;
    }
    if (Milisec == 60000) {
      __set_FAULTMASK(1); // 关闭所有中端
      NVIC_SystemReset(); // 复位
      // Milisec = 0;
    }
  }
}
